package Utils.test;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class Util {

    public static String getDate() {
        LocalDateTime localDate = LocalDateTime.now();
        localDate = localDate.minusDays(1);
        DateTimeFormatter dateObj = DateTimeFormatter.ofPattern("MM/dd/yyyy");
        return localDate.format(dateObj);

    }

    public static void screenShot(String gameName) throws AWTException, IOException, InterruptedException {
        Robot robot = new Robot();
        BufferedImage screenShot = robot.createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
        robot.mouseWheel(100);
        sleep(3000);
        ImageIO.write(screenShot, "JPG", new File("C:\\Users\\grzegorzbuj\\Desktop\\Screenshots\\" + gameName + ".jpg"));
    }


    public static void getReportName(String repoName) {
        StringSelection stringSelection = new StringSelection(repoName);
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(stringSelection, stringSelection);
    }

    public static void sleep(int milSec) throws InterruptedException {
        Thread.sleep(milSec);
    }

    public static void sleepShort() throws InterruptedException {
        Thread.sleep(1000);
    }




}




