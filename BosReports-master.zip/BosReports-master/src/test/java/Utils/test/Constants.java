package Utils.test;

public class Constants {

    public static final String PLI_URL = "http://10.92.228.14/L5IRE/Login.aspx?ReturnUrl=%2fL5IRE%2fmodules%2fDefault.aspx";
    public static final String BOS_USER = "badmin";
    public static final String BOS_PASS = "badmin";
    public static final String CHROME = "webdriver.chrome.driver";
    public static final String CHROME_PATH = "C:/Users/grzegorzbuj/Desktop/Drivers/chromedriver.exe";
    public static final String RANGE_ALL_START = "00000001";
    public static final String RANGE_ALL_END = "99999999";
    public static final String RANGE_TERMINAL_END = "89999999";
    public static final String RANGE_INTERNET_START = "90000000";
    public static final String RANGE_INTERNET_END = "99999999";


    //ACC DAILY
    public static final String ACC_DAILY_ALL = "Daily Sales Report - Acc. - All";
    public static final String ACC_DAILY_TERMINAL = "Daily Sales Report - Acc. - Terminal";
    public static final String ACC_DAILY_INTERNET = "Daily Sales Report - Acc. - Internet";
    public static final String ACC_GAME_ALL = "Game Sales Report - All";
    public static final String ACC_GAME_TERMINAL = "Game Sales Report - Terminal";
    public static final String ACC_GAME_INTERNET = "Game Sales Report - Internet";
    public static final String OVERALL_WALLET = "Overall Wallet Transactions";
    public static final String WALLET_TRANSACTIONS_PER_PLAYERS = "Wallet Transactions Per Registered Players";


    // ADVANCE SALES REPORT ALL
    public static final String RAF_ADV_ALL = "RAF Advance Sales Report - All";
    public static final String LOT_ADV_ALL = "LOT Advance Sales Report - All";
    public static final String LPS_ADV_ALL = "LPS Advance Sales Report - All";
    public static final String EUM_ADV_ALL = "EUM Advance Sales Report - All";
    public static final String EPS_ADV_ALL = "EPS Advance Sales Report - All";
    public static final String IOR_ADV_ALL = "IOR Advance Sales Report - All";
    public static final String DMN_ADV_ALL = "DMN Advance Sales Report - All";
    public static final String DMP_ADV_ALL = "DMP Advance Sales Report - All";

    // ADVANCE SALES REPORT TERMINAL


    public static final String RAF_ADV_TERMINAL = "RAF Advance Sales Report - Terminal";
    public static final String LOT_ADV_TERMINAL = "LOT Advance Sales Report - Terminal";
    public static final String LPS_ADV_TERMINAL = "LPS Advance Sales Report - Terminal";
    public static final String EUM_ADV_TERMINAL = "EUM Advance Sales Report - Terminal";
    public static final String EPS_ADV_TERMINAL = "EPS Advance Sales Report - Terminal";
    public static final String IOR_ADV_TERMINAL = "IOR Advance Sales Report - Terminal";
    public static final String DMN_ADV_TERMINAL = "DMN Advance Sales Report - Terminal";
    public static final String DMP_ADV_TERMINAL = "DMP Advance Sales Report - Terminal";
    public static final String L5_ADV_TERMINAL = "L51 Advance Sales Report - Terminal";
    public static final String L51_ADV_TERMINAL = "L51+1 Advance Sales Report - Terminal";
    public static final String L52_ADV_TERMINAL = "L51+2 Advance Sales Report - Terminal";
    public static final String TVB_ADV_TERMINAL = "TVB Advance Sales Report - Terminal";


    // ADVANCE SALES REPORT INTERNET
    public static final String RAF_ADV_INTERNET = "RAF Advance Sales Report - Internet";
    public static final String LOT_ADV_INTERNET = "LOT Advance Sales Report - Internet";
    public static final String LPS_ADV_INTERNET = "LPS Advance Sales Report - Internet";
    public static final String EUM_ADV_INTERNET = "EUM Advance Sales Report - Internet";
    public static final String EPS_ADV_INTERNET = "EPS Advance Sales Report - Internet";
    public static final String IOR_ADV_INTERNET = "IOR Advance Sales Report - Internet";
    public static final String DMN_ADV_INTERNET = "DMN Advance Sales Report - Internet";
    public static final String DMP_ADV_INTERNET = "DMP Advance Sales Report - Internet";


    // TRANSACTIONS PER CHANNEL ALL


    public static final String RAF_TRANS_PER_CHANNEL_ALL = "RAF Transactions Per Channel - All";

    public static final String LOT_TRANS_PER_CHANNEL_ALL = "LOT Transactions Per Channel - All";
    public static final String LPS_TRANS_PER_CHANNEL_ALL = "LPS Transactions Per Channel - All";
    public static final String EUM_TRANS_PER_CHANNEL_ALL = "EUM Transactions Per Channel - All";
    public static final String EPS_TRANS_PER_CHANNEL_ALL = "EPS Transactions Per Channel - All";
    public static final String IOR_TRANS_PER_CHANNEL_ALL = "IOR Transactions Per Channel - All";
    public static final String DMN_TRANS_PER_CHANNEL_ALL = "DMN Transactions Per Channel - All";
    public static final String DMP_TRANS_PER_CHANNEL_ALL = "DMP Transactions Per Channel - All";


    // TRANSACTIONS PER CHANNEL TERMINAL


    public static final String RAF_TRANS_PER_CHANNEL_TERMINAL = "RAF Transactions Per Channel - Terminal";
    public static final String LOT_TRANS_PER_CHANNEL_TERMINAL = "LOT Transactions Per Channel - Terminal";
    public static final String LPS_TRANS_PER_CHANNEL_TERMINAL = "LPS Transactions Per Channel - Terminal";
    public static final String EUM_TRANS_PER_CHANNEL_TERMINAL = "EUM Transactions Per Channel - Terminal";
    public static final String EPS_TRANS_PER_CHANNEL_TERMINAL = "EPS Transactions Per Channel - Terminal";
    public static final String IOR_TRANS_PER_CHANNEL_TERMINAL = "IOR Transactions Per Channel - Terminal";
    public static final String DMN_TRANS_PER_CHANNEL_TERMINAL = "DMN Transactions Per Channel - Terminal";
    public static final String DMP_TRANS_PER_CHANNEL_TERMINAL = "DMP Transactions Per Channel - Terminal";
    public static final String L5_TRANS_PER_CHANNEL_TERMINAL = "L51 Transactions Per Channel - Terminal";
    public static final String L51_TRANS_PER_CHANNEL_TERMINAL = "L51+1 Transactions Per Channel - Terminal";
    public static final String L52_TRANS_PER_CHANNEL_TERMINAL = "L51+2 Transactions Per Channel - Terminal";
    public static final String TVB_TRANS_PER_CHANNEL_TERMINAL = "TVB Transactions Per Channel - Terminal";


    // TRANSACTIONS PER CHANNEL TERMINAL


    public static final String RAF_TRANS_PER_CHANNEL_INTERNET = "RAF Transactions Per Channel - Internet";
    public static final String LOT_TRANS_PER_CHANNEL_INTERNET = "LOT Transactions Per Channel - Internet";
    public static final String LPS_TRANS_PER_CHANNEL_INTERNET = "LPS Transactions Per Channel - Internet";
    public static final String EUM_TRANS_PER_CHANNEL_INTERNET = "EUM Transactions Per Channel - Internet";
    public static final String EPS_TRANS_PER_CHANNEL_INTERNET = "EPS Transactions Per Channel - Internet";
    public static final String IOR_TRANS_PER_CHANNEL_INTERNET = "IOR Transactions Per Channel - Internet";
    public static final String DMN_TRANS_PER_CHANNEL_INTERNET = "DMN Transactions Per Channel - Internet";
    public static final String DMP_TRANS_PER_CHANNEL_INTERNET = "DMP Transactions Per Channel - Internet";


    //TRANSACTIONS PER CHANNEL  AND DRAW

    public static final String RAF_TRANS_AND_DRAW = "RAF Transactions Per Channel And Draw - ";
    public static final String LOT_TRANS_AND_DRAW = "LOT Transactions Per Channel And Draw - ";
    public static final String LPS_TRANS_AND_DRAW = "LPS Transactions Per Channel And Draw - ";
    public static final String EUM_TRANS_AND_DRAW = "EUM Transactions Per Channel And Draw -";
    public static final String EPS_TRANS_AND_DRAW = "EPS Transactions Per Channel And Draw -";
    public static final String IOR_TRANS_AND_DRAW = "IOR Transactions Per Channel And Draw - ";
    public static final String DMN_TRANS_AND_DRAW = "DMN Transactions Per Channel And Draw -";
    public static final String DMP_TRANS_AND_DRAW = "DMP Transactions Per Channel And Draw - ";
    public static final String L5_TRANS_AND_DRAW = "L51 Transactions Per Channel And Draw -";
    public static final String L51_TRANS_AND_DRAW = "L51+1 Transactions Per Channel And Draw -";
    public static final String L52_TRANS_AND_DRAW = "L51+2 Transactions Per Channel And Draw -";
    public static final String TVB_TRANS_AND_DRAW = "TVB Transactions Per Channel And Draw -";


    //BOIPA

    public static final String WEB_CASHIN_TRANSACTIONS = "Registered players Web Cashin Transaction";
    public static final String BOIPA_TRANSACTIONS_REPORT = "BOIPA Transactions Report";
    public static final String BOIPA_ADD_FUNDS_ALL = "BOIPA Add Funds Report - All";
    public static final String BOIPA_ADD_FUNDS_PENDING_RES = "BOIPA Add Funds Report - Pending response";
    public static final String BOIPA_ADD_FUNDS_PENDING = "BOIPA Add Funds Report - Pending";
    public static final String BOIPA_ADD_FUNDS_SUCCESS = "BOIPA Add Funds Report - Success";
    public static final String BOIPA_ADD_FUNDS_REJECTED_PP = "BOIPA Add Funds Report - Rejected by PP";

    //IWG

    public static final String IWG_TRANS_ALL = "IWG Transactions Per Channel - All";

    public static final String IWG_TRANS_DESKTOP = "IWG Transactions Per Channel - Desktop";
    public static final String IWG_TRANS_MOBILE = "IWG Transactions Per Channel - Mobile";
    public static final String IWG_TRANS_IOS = "IWG Transactions Per Channel - IOS";
    public static final String IWG_TRANS_ANDROID = "IWG Transactions Per Channel - Android";
    public static final String IWG_TRANS_SUBSCRIPTIONS = "IWG Transactions Per Channel - Subscriptions";
    public static final String IWG_TRANS_INTERNET = "IWG Transactions Per Channel - Internet";
    //RAF ALL CHANNELS


    //WEEKLY REPORT BY PRODUCT


    public static final String INSTANT_WEEKLY = "Instant Weekly Invoice Report By Product";
    public static final String RAF_WEEKLY = "RAF Weekly Invoice Report By Product";
    public static final String LOT_WEEKLY = "LOT Weekly Invoice Report By Product";
    public static final String LPS_WEEKLY = "LPS Weekly Invoice Report By Product";
    public static final String EUM_WEEKLY = "EUM Weekly Invoice Report By Product";
    public static final String EPS_WEEKLY = "EPS Weekly Invoice Report By Product";
    public static final String IOR_WEEKLY = "IOR Weekly Invoice Report By Product";
    public static final String DMN_WEEKLY = "DMN Weekly Invoice Report By Product";
    public static final String DMP_WEEKLY = "DMP Weekly Invoice Report By Product";
    public static final String L5_WEEKLY = "L5 Weekly Invoice Report By Product";
    public static final String L51_WEEKLY = "L5 + 1 Weekly Invoice Report By Product";
    public static final String L52_WEEKLY = "L5 + 2 Weekly Invoice Report By Product";
    public static final String TVB_WEEKLY = "TVB Weekly Invoice Report By Product";

    public static final int X = 1499;
    public static final int Y = 729;
    public static final String BOS_LINK_DAILY = "Reports";
    public static final String SUBMENU_ACC_REPORT = "asplnkbtn86";
    public static final String DAILY_REPORT = "asplnkbtn86";

    public static final String DATE_PICKER = "app_551_dat_3_dt_txt";
    public static final String PDF_BUTTON = "app_551_btnPdf";
    public static final String LINK_TO_GAME_REPORT = "app_550_AppDataList_ctl03_lnkAppTitle";
    public static final String LINK_TO_DAILY_REPORT = "app_550_AppDataList_ctl02_lnkAppTitle";
    public static final String GAME_DATE_PICKER = "app_552_dat_3_dt_txt";

    public static final String PDF_GAME_BUTTON = "app_552_btnPdf";
    public static final String GAME_SELECTOR_TERMINAL = "#app_552_lst_4 > option:nth-child(2)";
    public static final String GAME_SELECTOR_INTERNET = "#app_552_lst_4 > option:nth-child(3)";
    public static final String SUBMENU_WALLET_REPORT = "asplnkbtn87";
    public static final String LINK_WALLET_REPORT = "app_960_AppDataList_ctl03_lnkAppTitle";
    public static final String WALL_DATE_PICKER_1 = "app_969_dat_1_dt_txt";
    public static final String WALL_DATE_PICKER_2 = "app_969_dat_2_dt_txt";
    public static final String WALL_PDF_BUTTON = "app_969_btnPdf";
    public static final int WALLET_CLOSING_XX = 1517;
    public static final int WALLET_CLOSING_YY = 795;
    public static final String LINK_WALL_REG_REPORT = "app_960_AppDataList_ctl02_lnkAppTitle";
    public static final String WALL_REG_DATE_PICKER = "app_968_dat_1_dt_txt";
    public static final String RANGE_FIELD_1 = "app_968_txt_2";
    public static final String RANGE_FIELD_2 = "app_968_txt_3";

    public static final String RANGE_NUM_START = "1";
    public static final String RANGE_NUM_END = "99999999";
    public static final String WALL_REG_PDF_BUTTON = "app_968_btnPdf";
    public static final String SUBMENU_ADV_REPORT = "asplnkbtn85";

    public static final String LINK_TO_ADV_REPORT = "app_124_AppDataList_ctl06_lnkAppTitle";
    public static final String DATE_ADV_PICKER = "app_538_dat_4_dt_txt";
    public static final String PDF_ADV_BUTTON = "app_538_btnPdf";
    public static final String LOT_ADV_GAME_FIELD = "#app_538_lst_1 > option:nth-child(2)";

    //Advance

    public static final String LPS_ADV_SUB_GAME_FIELD = "#app_538_lst_2 > option:nth-child(2)";
    public static final String EPS_ADV_SUB_GAME_FIELD = "#app_538_lst_2 > option:nth-child(2)";
    public static final String EUM_ADV_SUB_GAME_FIELD = "#app_538_lst_1 > option:nth-child(3)";
    public static final String IOR_ADV_SUB_GAME_FIELD = "#app_538_lst_2 > option:nth-child(3)";
    public static final String DMN_ADV_GAME_FIELD = "#app_538_lst_1 > option:nth-child(4)";
    public static final String DMP_ADV_SUB_GAME_FIELD = "#app_538_lst_2 > option:nth-child(2)";
    public static final String L54321_ADV_GAME_FIELD = "#app_538_lst_1 > option:nth-child(5)";
    public static final String RAF_ADV_GAME_FIELD = "#app_538_lst_1 > option:nth-child(1)";
    public static final String ADV_TERMINAL = "#app_538_lst_3 > option:nth-child(2)";
    public static final String ADV_INTERNET = "#app_538_lst_3 > option:nth-child(3)";
    public static final String L51_ADV_SUB_GAME_FIELD = "#app_538_lst_2 > option:nth-child(2)";
    public static final String L52_ADV_SUB_GAME_FIELD = "#app_538_lst_2 > option:nth-child(3)";
    public static final String TVB_ADV_GAME_FIELD = "#app_538_lst_1 > option:nth-child(6)";


    //TRANSACTIONS

    public static final String LOT_TRANS_GAME_FIELD = "#app_616_lst_1 > option:nth-child(2)";

    public static final String LPS_TRANS_SUB_GAME_FIELD = "#app_616_lst_2 > option:nth-child(2)";
    public static final String EPS_TRANS_SUB_GAME_FIELD = "#app_616_lst_2 > option:nth-child(2)";
    public static final String EUM_TRANS_SUB_GAME_FIELD = "#app_616_lst_1 > option:nth-child(3)";
    public static final String IOR_TRANS_SUB_GAME_FIELD = "#app_616_lst_2 > option:nth-child(3)";
    public static final String DMN_TRANS_GAME_FIELD = "#app_616_lst_1 > option:nth-child(4)";
    public static final String DMP_TRANS_SUB_GAME_FIELD = "#app_616_lst_2 > option:nth-child(2)";
    public static final String L54321_TRANS_GAME_FIELD = "#app_616_lst_1 > option:nth-child(5)";
    public static final String RAF_TRANS_GAME_FIELD = "#app_616_lst_1 > option:nth-child(1)";
    public static final String TRANS_TERMINAL = "#app_616_lst_3 > option:nth-child(2)";
    public static final String TRANS_INTERNET = "#app_616_lst_3 > option:nth-child(8)";
    public static final String L51_TRANS_SUB_GAME_FIELD = "#app_616_lst_2 > option:nth-child(2)";
    public static final String L52_TRANS_SUB_GAME_FIELD = "#app_616_lst_2 > option:nth-child(3)";
    public static final String TVB_TRANS_GAME_FIELD = "#app_616_lst_1 > option:nth-child(6)";
    public static final String DATE_TRANS_PICKER1 = "#app_616_dat_4_dt_txt";
    public static final String DATE_TRANS_PICKER1_SPPT = "#app_602_dat_4_dt_txt";
    public static final String DATE_TRANS_PICKER2 = "#app_616_dat_5_dt_txt";
    public static final String DATE_TRANS_PICKER2_SPPT = "#app_602_dat_5_dt_txt";
    public static final String TANS_BUTTON = "app_616_btnPdf";

    public static final String LINK_TO_TRANS_REPORT = "app_124_AppDataList_ctl01_lnkAppTitle";
    public static final String LINK_TO_SALES_PER_PRODUCT_TYPE = "app_124_AppDataList_ctl02_lnkAppTitle";




    //TRANSACTION AND DRAW

    public static final String LINK_TO_TRANS_AND_DRAW = "app_124_AppDataList_ctl03_lnkAppTitle";
    public static final String DATE_TRANS_AND_DRAW_PICKER = "#app_450_dat_3_dt_txt";
    public static final String DRAW_FIELD_TRANS = "#app_615_lst_5";
    public static final String SECOND_DRAW_FIELD_TRANS = "#app_615_lst_5 > option:nth-child(2)";
    public static final String TRANS_BUTTON = "app_615_btnPdf";

    public static final String RAF_T_DRAW = "app_615_dat_4_dt_txt";
    public static final String LOTTO_T_DRAW = "#app_615_lst_1 > option:nth-child(2)";
    public static final String LPS_T_DRAW = "#app_615_lst_2 > option:nth-child(2)";
    public static final String EUM_T_DRAW = "#app_615_lst_1 > option:nth-child(3)";
    public static final String EPS_T_DRAW = "#app_615_lst_2 > option:nth-child(2)";
    public static final String IOR_T_DRAW = "#app_615_lst_2 > option:nth-child(3)";
    public static final String DMN_T_DRAW = "#app_615_lst_1 > option:nth-child(4)";
    public static final String DMP_T_DRAW = "#app_615_lst_2 > option:nth-child(2)";
    public static final String L5_T_DRAW = "#app_615_lst_1 > option:nth-child(5)";
    public static final String L51_T_DRAW = "#app_615_lst_2 > option:nth-child(2)";
    public static final String L52_T_DRAW = "#app_615_lst_2 > option:nth-child(3)";
    public static final String TVB_T_DRAW = "#app_615_lst_1 > option:nth-child(6)";

    //TRANSACTIONS PER PRODUCT TYPE

    public static final String SPPT_INTERNET = "#app_602_lst_3 > option:nth-child(3)";
    public static final String SPPT_TERMINAL = "#app_602_lst_3 > option:nth-child(2)";

    public static final String LOT_TRANS_PER_PRODUCT_TYPE_ADDRESS = "#app_602_lst_1 > option:nth-child(2)";
    public static final String RAF_TRANS_PER_PRODUCT_TYPE_ADDRESS = "#app_602_lst_1 > option:nth-child(1)";
    public static final String LPS_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS = "#app_602_lst_2 > option:nth-child(2)";
    public static final String EUM_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS = "#app_602_lst_1 > option:nth-child(3)";
    public static final String IOR_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS = "#app_602_lst_2 > option:nth-child(3)";
    public static final String EPS_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS = "#app_602_lst_2 > option:nth-child(2)";
    public static final String DMN_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS = "#app_602_lst_1 > option:nth-child(4)";
    public static final String DMP_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS = "#app_602_lst_2 > option:nth-child(2)";
    public static final String L54321_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS = "#app_602_lst_1 > option:nth-child(5)";
    public static final String L54321_1_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS = "#app_602_lst_2 > option:nth-child(2)";
    public static final String L54321_2_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS = "#app_602_lst_2 > option:nth-child(3)";
    public static final String TVB_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS = "#app_602_lst_1 > option:nth-child(6)";

//SALES_PER_PRODUCT_TYPE_ALL

    public static final String RAF_SALES_PER_PRODUCT_TYPE_ALL = "RAF Sales Per Product Type - All";
    public static final String LOT_SALES_PER_PRODUCT_TYPE_ALL = "LOT Sales Per Product Type - All";
    public static final String LPS_SALES_PER_PRODUCT_TYPE_ALL = "LPS Sales Per Product Type - All";
    public static final String EUM_SALES_PER_PRODUCT_TYPE_ALL = "EUM Sales Per Product Type - All";
    public static final String EPS_SALES_PER_PRODUCT_TYPE_ALL = "EPS Sales Per Product Type - All";
    public static final String IOR_SALES_PER_PRODUCT_TYPE_ALL = "IOR Sales Per Product Type - All";
    public static final String DMN_SALES_PER_PRODUCT_TYPE_ALL = "DMN Sales Per Product Type - All";
    public static final String DMP_SALES_PER_PRODUCT_TYPE_ALL = "DMP Sales Per Product Type - All";
    public static final String L54321_SALES_PER_PRODUCT_TYPE_ALL = "L54321 Sales Per Product Type - All";
    public static final String L54321_1_SALES_PER_PRODUCT_TYPE_ALL = "L54321_1 Sales Per Product Type - All";
    public static final String L54321_2_SALES_PER_PRODUCT_TYPE_ALL = "L54321_2 Sales Per Product Type - All";
    public static final String TVB_SALES_PER_PRODUCT_TYPE_ALL = "TVB Sales Per Product Type - All";

//SALES_PER_PRODUCT_TYPE_TERMINAL

    public static final String RAF_SALES_PER_PRODUCT_TYPE_Terminal = "RAF Sales Per Product Type - Terminal";
    public static final String LOT_SALES_PER_PRODUCT_TYPE_Terminal = "LOT Sales Per Product Type - Terminal";
    public static final String LPS_SALES_PER_PRODUCT_TYPE_Terminal = "LPS Sales Per Product Type - Terminal";
    public static final String EUM_SALES_PER_PRODUCT_TYPE_Terminal = "EUM Sales Per Product Type - Terminal";
    public static final String EPS_SALES_PER_PRODUCT_TYPE_Terminal = "EPS Sales Per Product Type - Terminal";
    public static final String IOR_SALES_PER_PRODUCT_TYPE_Terminal = "IOR Sales Per Product Type - Terminal";
    public static final String DMN_SALES_PER_PRODUCT_TYPE_Terminal = "DMN Sales Per Product Type - Terminal";
    public static final String DMP_SALES_PER_PRODUCT_TYPE_Terminal = "DMP Sales Per Product Type - Terminal";
    public static final String L54321_SALES_PER_PRODUCT_TYPE_Terminal = "L54321 Sales Per Product Type - Terminal";
    public static final String L54321_1_SALES_PER_PRODUCT_TYPE_Terminal = "L54321_1 Sales Per Product Type - Terminal";
    public static final String L54321_2_SALES_PER_PRODUCT_TYPE_Terminal = "L54321_2 Sales Per Product Type - Terminal";
    public static final String TVB_SALES_PER_PRODUCT_TYPE_Terminal = "TVB Sales Per Product Type - Terminal";



    //SALES_PER_PRODUCT_TYPE_INTERNET


    public static final String RAF_SALES_PER_PRODUCT_TYPE_Internet = "RAF Sales Per Product Type - Internet";
    public static final String LOT_SALES_PER_PRODUCT_TYPE_Internet = "LOT Sales Per Product Type - Internet";
    public static final String LPS_SALES_PER_PRODUCT_TYPE_Internet = "LPS Sales Per Product Type - Internet";
    public static final String EUM_SALES_PER_PRODUCT_TYPE_Internet = "EUM Sales Per Product Type - Internet";
    public static final String EPS_SALES_PER_PRODUCT_TYPE_Internet = "EPS Sales Per Product Type - Internet";
    public static final String IOR_SALES_PER_PRODUCT_TYPE_Internet = "IOR Sales Per Product Type - Internet";
    public static final String DMN_SALES_PER_PRODUCT_TYPE_Internet = "DMN Sales Per Product Type - Internet";
    public static final String DMP_SALES_PER_PRODUCT_TYPE_Internet = "DMP Sales Per Product Type - Internet";
    public static final String L54321_SALES_PER_PRODUCT_TYPE_Internet = "L54321 Sales Per Product Type - Internet";
    public static final String L54321_1_SALES_PER_PRODUCT_TYPE_Internet = "L54321_1 Sales Per Product Type - Internet";
    public static final String L54321_2_SALES_PER_PRODUCT_TYPE_Internet = "L54321_2 Sales Per Product Type - Internet";
    public static final String TVB_SALES_PER_PRODUCT_TYPE_Internet = "TVB Sales Per Product Type - Internet";


    public static final String TANS_BUTTON_SPPT = "app_602_btnPdf";
    public static final String LPS_TRANS_PER_PRODUCT_TYPE = "LPS Transactions Per Channel - All";




    //WEEKLY PER PRODUCT

    public static final String FROM_YEAR = "#app_573_lst_1 > option:nth-child(10)";
    public static final String TO_YEAR = "#app_573_lst_3 > option:nth-child(10)";

    public static final String RAF_WEEKLY_PER_PRODUCT = "#app_573_lst_7 > option:nth-child(2)";
    public static final String LOT_WEEKLY_PER_PRODUCT = "#app_573_lst_7 > option:nth-child(3)";
    public static final String LPS_WEEKLY_PER_PRODUCT = "#app_573_lst_8 > option:nth-child(2)";
    public static final String EUM_WEEKLY_PER_PRODUCT = "#app_573_lst_7 > option:nth-child(4)";
    public static final String EPS_WEEKLY_PER_PRODUCT = "#app_573_lst_8 > option:nth-child(2)";
    public static final String IOR_WEEKLY_PER_PRODUCT = "#app_573_lst_8 > option:nth-child(3)";
    public static final String DMN_WEEKLY_PER_PRODUCT = "#app_573_lst_7 > option:nth-child(5)";
    public static final String DMP_WEEKLY_PER_PRODUCT = "#app_573_lst_8 > option:nth-child(2)";
    public static final String L5_WEEKLY_PER_PRODUCT = "#app_573_lst_7 > option:nth-child(6)";
    public static final String L51_WEEKLY_PER_PRODUCT = "#app_573_lst_8 > option:nth-child(2)";
    public static final String L52_WEEKLY_PER_PRODUCT = "#app_573_lst_8 > option:nth-child(3)";
    public static final String TVB_WEEKLY_PER_PRODUCT = "#app_573_lst_7 > option:nth-child(7)";
    public static final String LINK_WEEKLY_PER_PRODUCT = "app_550_AppDataList_ctl07_lnkAppTitle";
    public static final String WEEKLY_PER_PRODUCT_BUTTON = "app_573_btnPdf";

    //IWG

    public static final String IWG_GAME = "#app_616_lst_1 > option:nth-child(7)";
    public static final String IWG_DATE_PICKER_1 = "app_616_dat_4_dt_txt";
    public static final String IWG_DATE_PICKER_2 = "app_616_dat_5_dt_txt";
    public static final String IWG_PDF_BUTTON = "app_616_btnPdf";

    public static final String IWG_CHANNEL_DESKTOP = "#app_616_lst_3 > option:nth-child(3)";
    public static final String IWG_CHANNEL_MOBILE = "#app_616_lst_3 > option:nth-child(4)";
    public static final String IWG_CHANNEL_IOS = "#app_616_lst_3 > option:nth-child(5)";
    public static final String IWG_CHANNEL_ANDROID = "#app_616_lst_3 > option:nth-child(6)";
    public static final String IWG_CHANNEL_SUBSCRIPTION = "#app_616_lst_3 > option:nth-child(7)";
    public static final String IWG_CHANNEL_INTERNET = "#app_616_lst_3 > option:nth-child(8)";


    public static final String SUB_ALL_GAMES = "app_616_lst_2";

    public static final String REPORTS_PCLUB = "asplnkbtn87";
    public static final String REPORTS = "Reports";
    public static final String BOIPA_ADD_FUNDS_REPORT = "app_960_AppDataList_ctl20_lnkAppTitle";
    public static final String BOIPA_WEB_CASHIN = "app_960_AppDataList_ctl05_lnkAppTitle";
    public static final String BOIPA_DATEPICKER1 = "app_972_dat_1_dt_txt";
    public static final String BOIPA_DATEPICKER2 = "app_972_dat_2_dt_txt";
    public static final String BOIPA_PDF_BUTTON = "app_972_btnPdf";
    public static final String BOIPA_TRAN_PDF_BUTTON = "app_986_btnPdf";
    public static final String BOIPA_FUNDS_PDF_BUTTON = "app_994_btnPdf";
    public static final String BOIPA_TRANSACTIONS = "app_960_AppDataList_ctl12_lnkAppTitle";

    public static final String BOIPA_TRAN_DATEPICKER1 = "app_986_dat_1_dt_txt";
    public static final String BOIPA_TRAN_DATEPICKER2 = "app_986_dat_2_dt_txt";

    public static final String BOIPA_FUNDS_DATEPICKER1 = "app_994_dat_1_dt_txt";
    public static final String BOIPA_FUNDS_DATEPICKER2 = "app_994_dat_2_dt_txt";
    public static final String PENDING_RESPONSE = "#app_994_lst_3 > option:nth-child(2)";
    public static final String PENDING = "#app_994_lst_3 > option:nth-child(3)";
    public static final String SUCCESS = "#app_994_lst_3 > option:nth-child(4)";
    public static final String REJECTED_BY_PP = "#app_994_lst_3 > option:nth-child(5)";

    //TERMINAL INFO

    public static final String MONITORING = "Monitoring";
    public static final String TERMINALS = "asplnkbtn46";


    public static final String LINK_TO_TERMINAL_TRANSACTIONS = "app_65_AppDataList_ctl01_lnkAppTitle";
    public static final String DATE_TERMINAL = "app_66_cldDate_dt_txt";
    public static final String CLOCK1 = "app_66_cldFromTm_dt_img";

    public static final String CLOCK2 = "app_66_cldToTm_dt_img";
    public static final String MAGNIFIER_BTN = "app_66_btnRetrieve";
    public static final String RETAILER_NO = "#app_66_txtRetailer";
    public static final String SIX_EIGHT = "68000001";
    public static final String ZERO_ONE = "09109001";

    public static final String TERMINAL_RAFFLE = "#app_66_ddlGames > option:nth-child(4)";
    public static final String TERMINAL_LOT = "#app_66_ddlGames > option:nth-child(5)";
    public static final String TERMINAL_EUROMILLIONS = "#app_66_ddlGames > option:nth-child(6)";
    public static final String TERMINAL_DMN = "#app_66_ddlGames > option:nth-child(7)";
    public static final String TERMINAL_L54321 = "#app_66_ddlGames > option:nth-child(8)";
    public static final String TERMINAL_TVB = "#app_66_ddlGames > option:nth-child(9)";

    public static final String PAGE_COUNTER = "app_66_grdPager_pbPages";
    public static final String ERROR_MSG = "#app_66_lblErrMessage";
    public static final String INSTANTS = "INSTANTS";
    public static final String RAFFLE = "RAFFLE";
    public static final String LOT = "LOT";
    public static final String EUROMILLIONS = "EUROMILLIONS";
    public static final String DMN = "DMN";
    public static final String TVB = "TVB";

    public static final String SUBMENU_DRAW_REPORT = "asplnkbtn84";
    public static final String LINK_TO_WINNER_REPORT = "app_100_AppDataList_ctl10_lnkAppTitle";
    public static final String PDF_BUTT_HIGH_WINNER = "app_450_btnPdf";
    public static final String DRAW_HIGH_WINNER = "#app_450_lst_4";
    public static final String DRAW_HIGH_WINNER_DMP = "#app_450_lst_4 > option:nth-child(1)";
    public static final String SECOND_DRAW_HIGH_WINNER = "#app_450_lst_4 > option:nth-child(2)";

    public static final String HWR_LOT = "#app_450_lst_1 > option:nth-child(2)";
    public static final String HWR_LPS = "#app_450_lst_2 > option:nth-child(2)";
    public static final String LPS = "LPS";
    public static final String HWR_EUM = "#app_450_lst_1 > option:nth-child(3)";

    public static final String EUM = "EUM";

    public static final String HWR_EPS = "#app_450_lst_2 > option:nth-child(2)";
    public static final String EPS = "EPS";

    public static final String HWR_IOR = "#app_450_lst_2 > option:nth-child(3)";
    public static final String IOR = "IOR";

    public static final String HWR_DMN = "#app_450_lst_1 > option:nth-child(4)";

    public static final String HWR_DMP = "#app_450_lst_2 > option:nth-child(2)";
    public static final String DMP = "DMP";

    public static final String HWR_L5 = "#app_450_lst_1 > option:nth-child(5)";


    public static final String L5 = "L54321";

    public static final String HWR_L51 = "#app_450_lst_2 > option:nth-child(2)";

    public static final String L51 = "L5 + 1";

    public static final String HWR_L52 = "#app_450_lst_2 > option:nth-child(3)";

    public static final String L52 = "L5 + 2";

    public static final String HWR_TVB = "#app_450_lst_1 > option:nth-child(6)";


    public static final String DATE = "06/07/2023";
}


