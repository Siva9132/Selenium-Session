package Utils.test;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.IOException;

import static Utils.test.Util.getDate;
import static Utils.test.Util.sleep;


public class Singleton {

    public static WebDriver driver = null;
    public static String browserName = "chrome";
    public Constants constants;

    public static void initialize() throws InterruptedException {

        if (driver == null) {
            if (browserName.equalsIgnoreCase("chrome")) {
                System.setProperty(Constants.CHROME, Constants.CHROME_PATH);
                driver = new ChromeDriver();
                driver.manage().window().maximize();
                driver.manage().deleteAllCookies();
                System.out.println("Test start...");
                driver.get(Constants.PLI_URL);
                sleep(2000);
            }
        }
    }

    public static void mouseConfirm() throws AWTException, InterruptedException {

        Robot robot = new Robot();
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_V);
        robot.delay(100);
        robot.keyRelease(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_CONTROL);
        robot.delay(100);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.delay(100);
        robot.keyRelease(KeyEvent.VK_ENTER);
        robot.delay(100);
        Thread.sleep(1000);

    }

    public static void mouseConfirmInfo() throws AWTException {

        Robot robot = new Robot();
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_V);
        robot.delay(100);
        robot.keyRelease(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_CONTROL);
        robot.delay(100);

    }

    public static void quit() {
        System.out.println("quitting the browser");
        driver.quit();
        driver = null;

    }


    public static void close() {
        System.out.println("Download completed - closing the browser....");
        driver.close();

    }

    public static void logOn() throws AWTException, InterruptedException {

        driver.findElement(By.id("txtUsername")).click();
        sleep(3000);
        driver.findElement(By.id("txtUsername")).clear();
        driver.findElement(By.id("txtUsername")).sendKeys(Constants.BOS_USER);
        driver.findElement(By.id("txtPassword")).clear();
        driver.findElement(By.id("txtPassword")).sendKeys(Constants.BOS_PASS);
        driver.findElement(By.id("Btnsubmit")).click();
        sleep(2000);

    }


    public static void navigationDaily(String menu, String subMenu, String linkToReport, String datePicker, String fromRet, String toRet, String pdfButton) throws InterruptedException {


        driver.findElement(By.linkText(menu)).click();
        sleep(1000);
        driver.findElement(By.id(subMenu)).click();
        sleep(1000);
        driver.findElement(By.id(linkToReport)).click();
        sleep(1000);
        //Daily sales report link
        driver.findElement(By.id(datePicker)).sendKeys(getDate());
        sleep(1000);
        //daily reports download set up
        driver.findElement(By.id("app_551_txt_4")).click();
        driver.findElement(By.id("app_551_txt_4")).clear();
        driver.findElement(By.id("app_551_txt_4")).sendKeys(fromRet);
        sleep(1000);
        driver.findElement(By.id("app_551_txt_5")).click();
        driver.findElement(By.id("app_551_txt_5")).clear();
        driver.findElement(By.id("app_551_txt_5")).sendKeys(toRet);
        sleep(1000);

        driver.findElement(By.id(pdfButton)).click();
        sleep(1000);

    }

    public static void navigationWeekly(String menu, String subMenu, String linkToReport, String fromYear, String toYear,
                                        String fromRet, String toRet, String pdfButton) throws InterruptedException {


        driver.findElement(By.linkText(menu)).click();
        sleep(1000);
        driver.findElement(By.id(subMenu)).click();
        sleep(1000);
        driver.findElement(By.id(linkToReport)).click();
        sleep(1000);
        //Daily sales report link
        driver.findElement(By.cssSelector(fromYear)).click();
        sleep(1000);
        driver.findElement(By.cssSelector(toYear)).click();
        sleep(1000);
        //daily reports download set up
        driver.findElement(By.id("app_573_txt_5")).click();
        sleep(1000);
        driver.findElement(By.id("app_573_txt_5")).clear();
        sleep(1000);
        driver.findElement(By.id("app_573_txt_5")).sendKeys(fromRet);
        sleep(1000);
        driver.findElement(By.id("app_573_txt_6")).click();
        driver.findElement(By.id("app_573_txt_6")).clear();
        driver.findElement(By.id("app_573_txt_6")).sendKeys(toRet);
        sleep(1000);

        driver.findElement(By.id(pdfButton)).click();
        sleep(1000);

    }


    public static void navigationDailyNext(String fromRet, String toRet, String pdfButton) throws InterruptedException {

        //daily reports download set up
        driver.findElement(By.id("app_551_txt_4")).click();
        driver.findElement(By.id("app_551_txt_4")).clear();
        driver.findElement(By.id("app_551_txt_4")).sendKeys(fromRet);
        sleep(1000);
        driver.findElement(By.id("app_551_txt_5")).click();
        driver.findElement(By.id("app_551_txt_5")).clear();
        driver.findElement(By.id("app_551_txt_5")).sendKeys(toRet);
        sleep(1000);

        driver.findElement(By.id(pdfButton)).click();
        sleep(1000);

    }

    public static void navigationGame(String submenu, String linkToReport, String datePicker, String pdfGameButton) throws InterruptedException {


        driver.findElement(By.id(submenu)).click();
        sleep(2000);
        driver.findElement(By.id(linkToReport)).click();
        sleep(2000);
        driver.findElement(By.id(datePicker)).sendKeys(getDate());
        sleep(2000);
        driver.findElement(By.id(pdfGameButton)).click();
        sleep(2000);


    }

    public static void navigationGameNext(String selector, String pdfButton) throws InterruptedException {

        driver.findElement(By.cssSelector(selector)).click();
        sleep(2000);
        driver.findElement(By.id(pdfButton)).click();
        sleep(2000);


    }

    public static void navigationWallet(String subMenu, String linkToReport, String datePicker, String datePicker2, String pdfButton) throws InterruptedException {


        driver.findElement(By.id(subMenu)).click();
        sleep(2000);
        driver.findElement(By.id(linkToReport)).click();
        sleep(2000);
        driver.findElement(By.id(datePicker)).sendKeys(getDate());
        sleep(1000);
        driver.findElement(By.id(datePicker2)).sendKeys(getDate());
        sleep(1000);
        driver.findElement(By.id(pdfButton)).click();
        sleep(2000);

    }

    public static void navigationWalletNext(String subMenu, String linkToReport, String datePicker, String rangeStart, String rangeEnd, String rangeStartNum, String rangeEndNum, String pdfButton) throws InterruptedException {

        //app_968_dat_1_dt_txt
        driver.findElement(By.id(subMenu)).click();
        sleep(1000);
        driver.findElement(By.id(linkToReport)).click();
        sleep(1000);
        driver.findElement(By.id(datePicker)).sendKeys(getDate());
        sleep(1000);
        driver.findElement(By.id(rangeStart)).sendKeys(rangeStartNum);
        sleep(1000);
        driver.findElement(By.id(rangeEnd)).sendKeys(rangeEndNum);
        sleep(1000);

        driver.findElement(By.id(pdfButton)).click();
        sleep(1000);

    }

    public static void navigationAdvance(String menu, String subMenu, String linkToAdv, String datePicker, String pdfButton) throws InterruptedException {


        driver.findElement(By.linkText(menu)).click();
        sleep(1000);
        driver.findElement(By.id(subMenu)).click();
        sleep(1000);
        driver.findElement(By.id(linkToAdv)).click();
        sleep(1000);
        driver.findElement(By.id(datePicker)).sendKeys(getDate());
        sleep(1000);
        driver.findElement(By.id(pdfButton)).click();
        sleep(1000);

    }

    public static void navigationBoipa(String menu, String subMenu, String linkToReport, String datePicker, String datePicker2, String pdfButton) throws InterruptedException {

        driver.findElement(By.linkText(menu)).click();
        sleep(1000);
        driver.findElement(By.id(subMenu)).click();
        sleep(1000);
        driver.findElement(By.id(linkToReport)).click();
        sleep(1000);
        driver.findElement(By.id(datePicker)).sendKeys(getDate());
        sleep(1000);
        driver.findElement(By.id(datePicker2)).sendKeys(getDate());
        sleep(1000);
        driver.findElement(By.id(pdfButton)).click();
        sleep(1000);

    }

    public static void navigationBoipaNext(String subMenu, String linkToReport, String datePicker, String datePicker2, String pdfButton) throws InterruptedException {

        driver.findElement(By.id(subMenu)).click();
        sleep(1000);
        driver.findElement(By.id(linkToReport)).click();
        sleep(1000);
        driver.findElement(By.id(datePicker)).sendKeys(getDate());
        sleep(1000);
        driver.findElement(By.id(datePicker2)).sendKeys(getDate());
        sleep(1000);
        driver.findElement(By.id(pdfButton)).click();
        sleep(1000);

    }


    public static void navigationTransactions(String menu, String subMenu, String linkToAdv, String datePicker1, String datePicker2, String pdfButton) throws InterruptedException {


        driver.findElement(By.linkText(menu)).click();
        sleep(1000);
        driver.findElement(By.id(subMenu)).click();
        sleep(1000);
        driver.findElement(By.id(linkToAdv)).click();
        sleep(1000);
        driver.findElement(By.cssSelector(datePicker1)).sendKeys(getDate());
        sleep(1000);
        driver.findElement(By.cssSelector(datePicker2)).sendKeys(getDate());
        sleep(1000);
        driver.findElement(By.id(pdfButton)).click();
        sleep(1000);

    }

    public static void navTransandDraw(String menu, String subMenu, String linkToAdv, String datePicker1, String game) throws InterruptedException {


        driver.findElement(By.linkText(menu)).click();
        sleep(1000);
        driver.findElement(By.id(subMenu)).click();
        sleep(1000);
        driver.findElement(By.id(linkToAdv)).click();
        sleep(5000);
        driver.findElement(By.id(datePicker1)).sendKeys(getDate());
        sleep(3000);
        driver.findElement(By.id(game)).click();
        sleep(3000);


    }

    public static void findDrawForGames(String drawField, String reportName) throws AWTException, InterruptedException {
        String drawNo = driver.findElement(By.cssSelector(drawField)).getText().trim();
        sleep(3000);
        if (drawNo.isEmpty()) {
            System.out.println("There is no draw: " + "at" + getDate() + " for " + reportName);
        } else {
            String text = reportName + drawNo;
            StringSelection stringSelection = new StringSelection(text);
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            clipboard.setContents(stringSelection, stringSelection);
            Singleton.pdf_button(Constants.TRANS_BUTTON);
            Singleton.mouseSave();
            Singleton.mouseConfirm();
            Singleton.mouseClosePdf(Constants.X, Constants.Y);
        }
    }

    public static void findHighWinner(String drawField, String reportName) throws AWTException, InterruptedException {
        String drawNo = driver.findElement(By.cssSelector(drawField)).getText().trim();
        sleep(3000);
        if (drawNo.isEmpty()) {
            System.out.println("There is no high winner : " + " at " + getDate() + " for " + reportName);
        } else {
            String text = reportName + " HIGH WINNERS REPORT " + drawNo;
            StringSelection stringSelection = new StringSelection(text);
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            clipboard.setContents(stringSelection, stringSelection);
            Singleton.pdf_button(Constants.PDF_BUTT_HIGH_WINNER);
            Singleton.mouseSave();
            Singleton.mouseConfirm();
            Singleton.mouseClosePdf(Constants.X, Constants.Y);
        }
    }

    public static void findSecondDraw(String drawField, String reportName) throws AWTException, InterruptedException {
        driver.findElement(By.cssSelector(drawField)).click();
        String drawNo = driver.findElement(By.cssSelector(drawField)).getText().trim();
        sleep(3000);
        if (drawNo.isEmpty()) {
            System.out.println("There is no draw: " + " on " + getDate() + " for " + reportName);
        } else {
            String text = reportName + drawNo;
            StringSelection stringSelection = new StringSelection(text);
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            clipboard.setContents(stringSelection, stringSelection);
            Singleton.pdf_button(Constants.TRANS_BUTTON);
            Singleton.mouseSave();
            Singleton.mouseConfirm();
            Singleton.mouseClosePdf(Constants.X, Constants.Y);
        }
    }

    public static void findHighWinnerSecondDraw(String drawField, String reportName) throws AWTException, InterruptedException {
        driver.findElement(By.cssSelector(drawField)).click();
        String drawNo = driver.findElement(By.cssSelector(drawField)).getText().trim();
        sleep(3000);
        if (drawNo.isEmpty()) {
            System.out.println("There is no draw: " + " on " + getDate() + " for " + reportName);
        } else {
            String text = reportName + "HIGH WINNERS REPORTS" + drawNo;
            StringSelection stringSelection = new StringSelection(text);
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            clipboard.setContents(stringSelection, stringSelection);
            Singleton.pdf_button(Constants.PDF_BUTT_HIGH_WINNER);
            Singleton.mouseSave();
            Singleton.mouseConfirm();
            Singleton.mouseClosePdf(Constants.X, Constants.Y);
        }
    }

    public static void scrollToElement(String elem) {

        WebElement element = driver.findElement(By.id(elem));
        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].scrollIntoView();", element);
        if (element.isDisplayed()) {
            element.getText();

        }
    }

    public static void checkIfExists(String elem, String gameName) throws AWTException, IOException, InterruptedException {

        WebElement element = driver.findElement(By.cssSelector(elem));
        if (element.isDisplayed()) {
            System.out.println("No Transacrtioms for :" + gameName);
        } else {
            Util.screenShot(gameName);
        }
    }


    public static void pdf_button(String pdfButton) {
        driver.findElement(By.id(pdfButton)).click();
    }


    public static void mouseSave() throws AWTException {

        Robot robot = new Robot();
        Dimension i = driver.manage().window().getSize();
        robot.mouseMove(i.getWidth() / 2, i.getHeight() / 2);
        robot.delay(1000);
        robot.mouseMove(i.getWidth() / 2, i.getHeight() / 2);
        robot.delay(1000);
        robot.mousePress(InputEvent.BUTTON3_DOWN_MASK);
        robot.delay(1000);
        robot.mouseRelease(InputEvent.BUTTON3_DOWN_MASK);
        robot.delay(1000);
        robot.mouseMove(i.getWidth() / 2 + 10, i.getHeight() / 2 + 10);
        robot.delay(1000);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.delay(1000);
        robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        robot.delay(1000);
        robot.keyPress(KeyEvent.VK_BACK_SPACE);
        robot.delay(100);
        robot.keyRelease(KeyEvent.VK_BACK_SPACE);
        robot.delay(100);

    }

    public static void mouseClosePdf(int x, int y) throws AWTException, InterruptedException {

        Robot robot = new Robot();
        robot.mouseMove(x, y);
        sleep(3000);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.delay(1000);
        robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        robot.delay(1000);
        sleep(3000);

    }

    public static void mouseClosePdfWallet(int x, int y) throws AWTException, InterruptedException {

        Robot robot = new Robot();
        robot.mouseMove(1517, 795);
        sleep(3000);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.delay(1000);
        robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        robot.delay(1000);
        sleep(3000);

    }


    public static void getReportName(String repoName) {
        StringSelection stringSelection = new StringSelection(repoName);
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(stringSelection, stringSelection);
    }


    public static void changeGame(String game, String pdfButton) throws InterruptedException {
        driver.findElement(By.cssSelector(game)).click();
        sleep(2000);
        driver.findElement(By.id(pdfButton)).click();
        sleep(2000);
    }

    public static void changeGameDraw(String game) throws InterruptedException {
        driver.findElement(By.cssSelector(game)).click();
        sleep(2000);
    }

    public static void changeSubDraw(String game) throws InterruptedException {
        driver.findElement(By.cssSelector(game)).click();
        sleep(2000);
    }

    public static void changeSubGame(String subGame, String pdfButton) throws InterruptedException {
        driver.findElement(By.cssSelector(subGame)).click();
        sleep(1000);
        driver.findElement(By.id(pdfButton)).click();
        sleep(11000);
    }

    public static void changeChannel(String channel) throws InterruptedException {
        sleep(2000);
        driver.findElement(By.cssSelector(channel)).click();
        sleep(2000);
    }


    public static void navigationIwg(String menu, String submenu, String linkToTrans, String iwgGame, String
            subGames, String datePicker1,
                                     String datePicker2, String iwgPdfButton) throws InterruptedException {

        driver.findElement(By.linkText(menu)).click();
        sleep(1000);
        driver.findElement(By.id(submenu)).click();
        sleep(1000);
        driver.findElement(By.id(linkToTrans)).click();
        sleep(1000);
        driver.findElement(By.cssSelector(iwgGame)).click();
        sleep(1000);
        driver.findElement(By.id(subGames)).sendKeys("ALL SUBGAMES");
        sleep(1000);
        driver.findElement(By.id(datePicker1)).sendKeys(getDate());
        sleep(1000);
        driver.findElement(By.id(datePicker2)).sendKeys(getDate());
        sleep(1000);
        driver.findElement(By.id(iwgPdfButton)).click();
        sleep(11000);
    }


    public static void navigationTerminal(String monitoring, String dailyReport, String linkToTerminalTransactions,
                                          String datePicker) throws InterruptedException {
        driver.findElement(By.linkText(monitoring)).click();
        sleep(1000);
        driver.findElement(By.id(dailyReport)).click();
        sleep(1000);
        driver.findElement(By.id(linkToTerminalTransactions)).click();
        sleep(1000);
        driver.findElement(By.id("app_66_cldDate_dt_imgdel")).click();
        sleep(1000);
        driver.findElement(By.id(datePicker)).sendKeys(getDate());
        sleep(1000);
    }

    public static void navigationTerminalNext(String clock1, String clock2, String retailer, String
            retailerNumber, String magnifier) throws InterruptedException, AWTException {
        driver.findElement(By.id(clock1)).click();
        sleep(5000);
        Robot robot = new Robot();
        robot.mouseMove(704, 482);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.keyPress(KeyEvent.VK_DELETE);
        robot.delay(100);
        robot.keyRelease(KeyEvent.VK_DELETE);
        robot.delay(100);
        Singleton.getReportName("00");
        Singleton.mouseConfirmInfo();


        robot.mouseMove(768, 480);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.keyPress(KeyEvent.VK_DELETE);
        robot.delay(100);
        robot.keyRelease(KeyEvent.VK_DELETE);
        robot.delay(100);
        Singleton.getReportName("00");
        Singleton.mouseConfirmInfo();


        robot.mouseMove(838, 482);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.keyPress(KeyEvent.VK_DELETE);
        robot.delay(100);
        robot.keyRelease(KeyEvent.VK_DELETE);
        robot.delay(100);
        Singleton.getReportName("01");
        Singleton.mouseConfirm();


        driver.findElement(By.id(clock2)).click();
        sleep(5000);


        robot.mouseMove(704, 482);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.keyPress(KeyEvent.VK_DELETE);
        robot.delay(100);
        robot.keyRelease(KeyEvent.VK_DELETE);
        robot.delay(100);
        Singleton.getReportName("23");
        Singleton.mouseConfirmInfo();


        robot.mouseMove(768, 480);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.keyPress(KeyEvent.VK_DELETE);
        robot.delay(100);
        robot.keyRelease(KeyEvent.VK_DELETE);
        robot.delay(100);
        Singleton.getReportName("59");
        Singleton.mouseConfirmInfo();


        robot.mouseMove(838, 482);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.keyPress(KeyEvent.VK_DELETE);
        robot.delay(100);
        robot.keyRelease(KeyEvent.VK_DELETE);
        robot.delay(100);
        Singleton.getReportName("59");
        Singleton.mouseConfirm();


        driver.findElement(By.cssSelector("#app_66_ddlGames > option:nth-child(3)")).click();
        sleep(3000);
        driver.findElement(By.cssSelector(retailer)).sendKeys(retailerNumber);
        sleep(3000);
        driver.findElement(By.id(magnifier)).click();
        sleep(3000);

    }


    public static void navHighWinner(String bosLinkDaily, String submenuDrawReport,
                                     String linkToWinnerReport, String dateTransAndDrawPicker) throws InterruptedException {

        driver.findElement(By.linkText(bosLinkDaily)).click();
        sleep(1000);
        driver.findElement(By.id(submenuDrawReport)).click();
        sleep(1000);
        driver.findElement(By.id(linkToWinnerReport)).click();
        sleep(1000);
        driver.findElement(By.cssSelector(dateTransAndDrawPicker)).sendKeys(getDate());
        sleep(1000);
        driver.findElement(By.cssSelector("#app_450_lst_5 > option:nth-child(2) ")).click();
        sleep(2000);
    }
}
