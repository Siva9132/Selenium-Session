package junit.test;
import Utils.test.Constants;
import Utils.test.Singleton;

import java.awt.*;

import static Utils.test.Constants.DATE_TRANS_AND_DRAW_PICKER;


public class TransactionsAndDrawReport {


    @org.junit.jupiter.api.Test
    public void bosTransactionsReport() throws InterruptedException, AWTException {

        //RAF TRANSACTIONS AND DRAW REPORT ALL

        Singleton.initialize();
        Singleton.logOn();

        //RAF
        Singleton.navTransandDraw(Constants.BOS_LINK_DAILY, Constants.SUBMENU_ADV_REPORT, Constants.LINK_TO_TRANS_AND_DRAW,Constants.RAF_T_DRAW, Constants.DATE_TRANS_AND_DRAW_PICKER);
        Singleton.findDrawForGames(Constants.DRAW_FIELD_TRANS, Constants.RAF_TRANS_AND_DRAW);

        //LOT
        Singleton.changeGameDraw(Constants.LOTTO_T_DRAW);
        Singleton.findDrawForGames(Constants.DRAW_FIELD_TRANS, Constants.LOT_TRANS_AND_DRAW);

        //LPS
        Singleton.changeSubDraw(Constants.LPS_T_DRAW);
        Singleton.findDrawForGames(Constants.DRAW_FIELD_TRANS, Constants.LPS_TRANS_AND_DRAW);

        //EUM
        Singleton.changeGameDraw(Constants.EUM_T_DRAW);
        Singleton.findDrawForGames(Constants.DRAW_FIELD_TRANS, Constants.EUM_TRANS_AND_DRAW);

        //EPS

        Singleton.changeSubDraw(Constants.EPS_T_DRAW);
        Singleton.findDrawForGames(Constants.DRAW_FIELD_TRANS, Constants.EPS_TRANS_AND_DRAW);

        //IOR

        Singleton.changeSubDraw(Constants.IOR_T_DRAW);
        Singleton.findDrawForGames(Constants.DRAW_FIELD_TRANS, Constants.IOR_TRANS_AND_DRAW);

        //DMN FIRST DRAW

        Singleton.changeGameDraw(Constants.DMN_T_DRAW);
        Singleton.findDrawForGames(Constants.DRAW_FIELD_TRANS, Constants.DMN_TRANS_AND_DRAW);

        //DMN SECOND DRAW

        Singleton.changeGameDraw(Constants.DMN_T_DRAW);
        Singleton.findSecondDraw(Constants.SECOND_DRAW_FIELD_TRANS, Constants.DMN_TRANS_AND_DRAW);


        //DMP FIRST DRAW

        Singleton.changeSubDraw(Constants.DMP_T_DRAW);
        Singleton.findDrawForGames(Constants.DRAW_FIELD_TRANS, Constants.DMP_TRANS_AND_DRAW);


        //DMP SECOND DRAW

        Singleton.changeSubDraw(Constants.DMP_T_DRAW);
        Singleton.findSecondDraw(Constants.SECOND_DRAW_FIELD_TRANS, Constants.DMP_TRANS_AND_DRAW);

        //L5

        Singleton.changeGameDraw(Constants.L5_T_DRAW);
        Singleton.findDrawForGames(Constants.DRAW_FIELD_TRANS, Constants.L5_TRANS_AND_DRAW);

        //L51

        Singleton.changeSubDraw(Constants.L51_T_DRAW);
        Singleton.findDrawForGames(Constants.DRAW_FIELD_TRANS, Constants.L51_TRANS_AND_DRAW);

        //L52

        Singleton.changeSubDraw(Constants.L52_T_DRAW);
        Singleton.findDrawForGames(Constants.DRAW_FIELD_TRANS, Constants.L52_TRANS_AND_DRAW);

        //TVB

        Singleton.changeGameDraw(Constants.TVB_T_DRAW);
        Singleton.findDrawForGames(Constants.DRAW_FIELD_TRANS, Constants.TVB_TRANS_AND_DRAW);

        Singleton.close();
        Singleton.quit();

    }

}
