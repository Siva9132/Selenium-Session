package junit.test;

import Utils.test.Constants;
import Utils.test.Singleton;

import java.awt.*;

import static Utils.test.Util.sleep;

public class TransactionsReport {


    @org.junit.jupiter.api.Test
    public void bosTransactionsReport() throws InterruptedException, AWTException {

        //RAF ADVANCE SALES REPORT ALL
        Singleton.initialize();
        Singleton.logOn();
        Singleton.navigationTransactions(Constants.BOS_LINK_DAILY,Constants.SUBMENU_ADV_REPORT, Constants.LINK_TO_TRANS_REPORT, Constants.DATE_TRANS_PICKER1
                ,Constants.DATE_TRANS_PICKER2 , Constants.TANS_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.RAF_TRANS_PER_CHANNEL_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.RAF_TRANS_PER_CHANNEL_ALL);
        sleep(1000);

        //LOT TRANSACTIONS SALES REPORT ALL

        Singleton.changeGame(Constants.LOT_TRANS_GAME_FIELD,Constants.TANS_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.LOT_TRANS_PER_CHANNEL_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.LOT_TRANS_PER_CHANNEL_ALL);
        sleep(1000);

        //LPS TRANSACTIONS SALES REPORT ALL

        Singleton.changeSubGame(Constants.LPS_TRANS_SUB_GAME_FIELD,Constants.TANS_BUTTON );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.LPS_TRANS_PER_CHANNEL_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.LPS_TRANS_PER_CHANNEL_ALL);
        sleep(1000);

        //EUM TRANSACTIONS SALES REPORT ALL

        Singleton.changeGame(Constants.EUM_TRANS_SUB_GAME_FIELD,Constants.TANS_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.EUM_TRANS_PER_CHANNEL_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.EUM_TRANS_PER_CHANNEL_ALL);
        sleep(1000);

        //EPS TRANSACTIONS SALES REPORT ALL

        Singleton.changeSubGame(Constants.EPS_TRANS_SUB_GAME_FIELD,Constants.TANS_BUTTON );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.EPS_TRANS_PER_CHANNEL_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.EPS_TRANS_PER_CHANNEL_ALL);
        sleep(1000);

        //IOR TRANSACTIONS SALES REPORT ALL

        Singleton.changeSubGame(Constants.IOR_TRANS_SUB_GAME_FIELD,Constants.TANS_BUTTON );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.IOR_TRANS_PER_CHANNEL_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.IOR_TRANS_PER_CHANNEL_ALL);
        sleep(1000);

        //DMN TRANSACTIONS SALES REPORT ALL

        Singleton.changeGame(Constants.DMN_TRANS_GAME_FIELD,Constants.TANS_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.DMN_TRANS_PER_CHANNEL_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.DMN_TRANS_PER_CHANNEL_ALL);
        sleep(1000);


        // DMP TRANSACTIONS SALES REPORT ALL
        Singleton.changeSubGame(Constants.DMP_TRANS_SUB_GAME_FIELD,Constants.TANS_BUTTON );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.DMP_TRANS_PER_CHANNEL_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.DMP_TRANS_PER_CHANNEL_ALL);
        sleep(1000);

       //RAF TRANSACTIONS SALES TERMINAL REPORT
        Singleton.changeChannel(Constants.TRANS_TERMINAL);
        Singleton.changeGame(Constants.RAF_TRANS_GAME_FIELD,Constants.TANS_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.RAF_TRANS_PER_CHANNEL_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.RAF_TRANS_PER_CHANNEL_TERMINAL);
        sleep(1000);

        //LOT TRANSACTIONS SALES TERMINAL REPORT

        Singleton.changeGame(Constants.LOT_TRANS_GAME_FIELD,Constants.TANS_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.LOT_TRANS_PER_CHANNEL_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.LOT_TRANS_PER_CHANNEL_TERMINAL);
        sleep(1000);

        //LPS TRANSACTIONS SALES TERMINAL REPORT

        Singleton.changeSubGame(Constants.EPS_TRANS_SUB_GAME_FIELD,Constants.TANS_BUTTON );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.LPS_TRANS_PER_CHANNEL_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.LPS_TRANS_PER_CHANNEL_TERMINAL);
        sleep(1000);

        //EUM  TRANSACTIONS SALES TERMINAL REPORT

        Singleton.changeGame(Constants.EUM_TRANS_SUB_GAME_FIELD,Constants.TANS_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.EUM_TRANS_PER_CHANNEL_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.EUM_TRANS_PER_CHANNEL_TERMINAL);
        sleep(1000);

        //EPS TRANSACTIONS SALES TERMINAL REPORT

        Singleton.changeSubGame(Constants.EPS_TRANS_SUB_GAME_FIELD,Constants.TANS_BUTTON );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.EPS_TRANS_PER_CHANNEL_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.EPS_TRANS_PER_CHANNEL_TERMINAL);
        sleep(1000);


        //IOR TRANSACTIONS SALES TERMINAL REPORT

        Singleton.changeSubGame(Constants.IOR_TRANS_SUB_GAME_FIELD,Constants.TANS_BUTTON );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.IOR_TRANS_PER_CHANNEL_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.IOR_TRANS_PER_CHANNEL_TERMINAL);
        sleep(1000);

        //DMN TRANSACTIONS SALES TERMINAL REPORT

        Singleton.changeGame(Constants.DMN_TRANS_GAME_FIELD,Constants.TANS_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.DMN_TRANS_PER_CHANNEL_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.DMN_TRANS_PER_CHANNEL_TERMINAL);
        sleep(1000);

        //DMP TRANSACTIONS SALES TERMINAL REPORT

        Singleton.changeSubGame(Constants.DMP_TRANS_SUB_GAME_FIELD,Constants.TANS_BUTTON );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.DMP_TRANS_PER_CHANNEL_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.DMP_TRANS_PER_CHANNEL_TERMINAL);
        sleep(1000);

        // L54321  TRANSACTIONS SALES TERMINAL REPORT

        Singleton.changeGame(Constants.L54321_TRANS_GAME_FIELD,Constants.TANS_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.L5_TRANS_PER_CHANNEL_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.L5_TRANS_PER_CHANNEL_TERMINAL);
        sleep(1000);

        // L54321 + 1  TRANSACTIONS SALES TERMINAL REPORT

        Singleton.changeSubGame(Constants.L51_TRANS_SUB_GAME_FIELD,Constants.TANS_BUTTON );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.L51_TRANS_PER_CHANNEL_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.L51_TRANS_PER_CHANNEL_TERMINAL);
        sleep(1000);

        // L54321 + 2  TRANSACTIONS SALES TERMINAL REPORT

        Singleton.changeSubGame(Constants.L52_TRANS_SUB_GAME_FIELD,Constants.TANS_BUTTON );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.L52_TRANS_PER_CHANNEL_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.L52_TRANS_PER_CHANNEL_TERMINAL);
        sleep(1000);

        //TVB  TRANSACTIONS SALES TERMINAL REPORT

        Singleton.changeGame(Constants.TVB_TRANS_GAME_FIELD,Constants.TANS_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.TVB_TRANS_PER_CHANNEL_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.TVB_TRANS_PER_CHANNEL_TERMINAL);
        sleep(1000);


        //RAF TRANSACTIONS SALES REPORT INTERNET

        Singleton.changeChannel(Constants.TRANS_INTERNET);
        Singleton.changeGame(Constants.RAF_TRANS_GAME_FIELD,Constants.TANS_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.RAF_TRANS_PER_CHANNEL_INTERNET);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.RAF_TRANS_PER_CHANNEL_INTERNET);
        sleep(1000);

        //LOT TRANSACTIONS SALES INTERNET REPORT

        Singleton.changeGame(Constants.LOT_TRANS_GAME_FIELD,Constants.TANS_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.LOT_TRANS_PER_CHANNEL_INTERNET);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.LOT_TRANS_PER_CHANNEL_INTERNET);
        sleep(1000);

        //LPS TRANSACTIONS SALES INTERNET REPORT

        Singleton.changeSubGame(Constants.EPS_TRANS_SUB_GAME_FIELD,Constants.TANS_BUTTON );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.LPS_TRANS_PER_CHANNEL_INTERNET);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.LPS_TRANS_PER_CHANNEL_INTERNET);
        sleep(1000);

        //EUM  TRANSACTIONS SALES INTERNET REPORT

        Singleton.changeGame(Constants.EUM_TRANS_SUB_GAME_FIELD,Constants.TANS_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.EUM_TRANS_PER_CHANNEL_INTERNET);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.EUM_TRANS_PER_CHANNEL_INTERNET);
        sleep(1000);

        //EPS TRANSACTIONS SALES INTERNET REPORT

        Singleton.changeSubGame(Constants.EPS_TRANS_SUB_GAME_FIELD,Constants.TANS_BUTTON );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.EPS_TRANS_PER_CHANNEL_INTERNET);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.EPS_TRANS_PER_CHANNEL_INTERNET);
        sleep(1000);


        //IOR TRANSACTIONS SALES INTERNET REPORT

        Singleton.changeSubGame(Constants.IOR_TRANS_SUB_GAME_FIELD,Constants.TANS_BUTTON );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.IOR_TRANS_PER_CHANNEL_INTERNET);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.IOR_TRANS_PER_CHANNEL_INTERNET);
        sleep(1000);

        //DMN TRANSACTIONS SALES INTERNET REPORT

        Singleton.changeGame(Constants.DMN_TRANS_GAME_FIELD,Constants.TANS_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.DMN_TRANS_PER_CHANNEL_INTERNET);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.DMN_TRANS_PER_CHANNEL_INTERNET);
        sleep(1000);

        //DMP TRANSACTIONS SALES INTERNET REPORT

        Singleton.changeSubGame(Constants.DMP_TRANS_SUB_GAME_FIELD,Constants.TANS_BUTTON );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.DMP_TRANS_PER_CHANNEL_INTERNET);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.DMP_TRANS_PER_CHANNEL_INTERNET);
        sleep(1000);





        Singleton.close();
        Singleton.quit();

    }
}
