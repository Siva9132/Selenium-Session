package junit.test;
import Utils.test.Constants;
import Utils.test.Singleton;


import java.awt.*;

import static Utils.test.Util.sleep;

public class IWG_All_Channels {

        @org.junit.jupiter.api.Test
        public void bosIwgAllChannels() throws InterruptedException, AWTException {


            //IWG ALL

            Singleton.initialize();
            Singleton.logOn();
            Singleton.navigationIwg(Constants.BOS_LINK_DAILY, Constants.SUBMENU_ADV_REPORT, Constants.LINK_TO_TRANS_REPORT,
                    Constants.IWG_GAME, Constants.SUB_ALL_GAMES, Constants.IWG_DATE_PICKER_1, Constants.IWG_DATE_PICKER_2,
                    Constants.IWG_PDF_BUTTON);
            Singleton.mouseSave();
            Singleton.getReportName(Constants.IWG_TRANS_ALL);
            Singleton.mouseConfirm();
            Singleton.mouseClosePdf(Constants.X, Constants.Y);
            System.out.println("Download Completed :" + Constants.IWG_TRANS_ALL);
            sleep(1000);

            //IWG DESKTOP

            Singleton.changeGame(Constants.IWG_CHANNEL_DESKTOP,Constants.IWG_PDF_BUTTON);
            Singleton.mouseSave();
            Singleton.getReportName(Constants.IWG_TRANS_DESKTOP);
            Singleton.mouseConfirm();
            Singleton.mouseClosePdf(Constants.X, Constants.Y);
            System.out.println("Download Completed :" + Constants.IWG_TRANS_DESKTOP);
            sleep(1000);

            //IWG MOBILE

            Singleton.changeGame(Constants.IWG_CHANNEL_MOBILE,Constants.IWG_PDF_BUTTON);
            Singleton.mouseSave();
            Singleton.getReportName(Constants.IWG_TRANS_MOBILE);
            Singleton.mouseConfirm();
            Singleton.mouseClosePdf(Constants.X, Constants.Y);
            System.out.println("Download Completed :" + Constants.IWG_TRANS_MOBILE);
            sleep(1000);

            // IWG IOS

            Singleton.changeGame(Constants.IWG_CHANNEL_IOS,Constants.IWG_PDF_BUTTON);
            Singleton.mouseSave();
            Singleton.getReportName(Constants.IWG_TRANS_IOS);
            Singleton.mouseConfirm();
            Singleton.mouseClosePdf(Constants.X, Constants.Y);
            System.out.println("Download Completed :" + Constants.IWG_TRANS_IOS);
            sleep(1000);

            //IWG ANDROID

            Singleton.changeGame(Constants.IWG_CHANNEL_ANDROID,Constants.IWG_PDF_BUTTON);
            Singleton.mouseSave();
            Singleton.getReportName(Constants.IWG_TRANS_ANDROID);
            Singleton.mouseConfirm();
            Singleton.mouseClosePdf(Constants.X, Constants.Y);
            System.out.println("Download Completed :" + Constants.IWG_TRANS_ANDROID);
            sleep(1000);

            //IWG SUBSCRIPTION

            Singleton.changeGame(Constants.IWG_CHANNEL_SUBSCRIPTION,Constants.IWG_PDF_BUTTON);
            Singleton.mouseSave();
            Singleton.getReportName(Constants.IWG_TRANS_SUBSCRIPTIONS);
            Singleton.mouseConfirm();
            Singleton.mouseClosePdf(Constants.X, Constants.Y);
            System.out.println("Download Completed :" + Constants.IWG_TRANS_SUBSCRIPTIONS);
            sleep(1000);

            //IWG INTERNET

            Singleton.changeGame(Constants.IWG_CHANNEL_INTERNET,Constants.IWG_PDF_BUTTON);
            Singleton.mouseSave();
            Singleton.getReportName(Constants.IWG_TRANS_INTERNET);
            Singleton.mouseConfirm();
            Singleton.mouseClosePdf(Constants.X, Constants.Y);
            System.out.println("Download Completed :" + Constants.IWG_TRANS_INTERNET);
            sleep(1000);

            Singleton.close();
            Singleton.quit();
    }
}
