package junit.test;

import Utils.test.Constants;
import Utils.test.Singleton;

import java.awt.*;
import java.io.IOException;

public class HighWinnerReport {


    @org.junit.jupiter.api.Test
    public void highWinnerReport() throws InterruptedException, AWTException, IOException {


        Singleton.initialize();
        Singleton.logOn();
        Singleton.navHighWinner(Constants.BOS_LINK_DAILY, Constants.SUBMENU_DRAW_REPORT,
                Constants.LINK_TO_WINNER_REPORT, Constants.DATE_TRANS_AND_DRAW_PICKER);

        Singleton.findHighWinner(Constants.DRAW_HIGH_WINNER,Constants.RAFFLE);

        Singleton.changeGameDraw(Constants.HWR_LOT);
        Singleton.findHighWinner(Constants.DRAW_HIGH_WINNER,Constants.LOT);

        Singleton.changeGameDraw(Constants.HWR_LPS);
        Singleton.findHighWinner(Constants.DRAW_HIGH_WINNER,Constants.LPS);

        Singleton.changeGameDraw(Constants.HWR_EUM);
        Singleton.findHighWinner(Constants.DRAW_HIGH_WINNER,Constants.EUM);

        Singleton.changeGameDraw(Constants.HWR_EPS);
        Singleton.findHighWinner(Constants.DRAW_HIGH_WINNER,Constants.EPS);

        Singleton.changeGameDraw(Constants.HWR_IOR);
        Singleton.findHighWinner(Constants.DRAW_HIGH_WINNER,Constants.IOR);

        Singleton.changeGameDraw(Constants.HWR_DMN);
        Singleton.findHighWinner(Constants.DRAW_HIGH_WINNER,Constants.DMN);

        //second draw

        Singleton.changeGameDraw(Constants.SECOND_DRAW_HIGH_WINNER);
        Singleton.findHighWinnerSecondDraw(Constants.SECOND_DRAW_HIGH_WINNER,Constants.DMN);


        Singleton.changeGameDraw(Constants.HWR_DMP);
        Singleton.findHighWinner(Constants.DRAW_HIGH_WINNER_DMP,Constants.DMP);

        //second draw

        Singleton.changeGameDraw(Constants.SECOND_DRAW_HIGH_WINNER);
        Singleton.findHighWinnerSecondDraw(Constants.SECOND_DRAW_HIGH_WINNER,Constants.DMP);


        Singleton.changeGameDraw(Constants.HWR_L5);
        Singleton.findHighWinner(Constants.DRAW_HIGH_WINNER,Constants.L5);

        Singleton.changeGameDraw(Constants.HWR_L51);
        Singleton.findHighWinner(Constants.DRAW_HIGH_WINNER,Constants.L51);

        Singleton.changeGameDraw(Constants.HWR_L52);
        Singleton.findHighWinner(Constants.DRAW_HIGH_WINNER,Constants.L52);

        Singleton.changeGameDraw(Constants.HWR_TVB);
        Singleton.findHighWinner(Constants.DRAW_HIGH_WINNER,Constants.TVB);

        Singleton.close();
        Singleton.quit();



    }
}
