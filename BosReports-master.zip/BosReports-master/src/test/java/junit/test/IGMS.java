package junit.test;

import Utils.test.Constants;
import Utils.test.Singleton;

import java.awt.*;

import static Utils.test.Util.sleep;

public class IGMS {


    @org.junit.jupiter.api.Test
    public void bosAdvanceReport() throws InterruptedException, AWTException {

        //RAF ADVANCE SALES REPORT ALL
        Singleton.initialize();
        Singleton.logOn();
        Singleton.navigationAdvance(Constants.BOS_LINK_DAILY, Constants.SUBMENU_ADV_REPORT, Constants.LINK_TO_ADV_REPORT, Constants.DATE_ADV_PICKER, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.RAF_ADV_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);

        System.out.println("Download Completed :" + Constants.RAF_ADV_ALL);
        sleep(1000);

        //LOT ADVANCE SALES REPORT ALL

        Singleton.changeGame(Constants.LOT_ADV_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.LOT_ADV_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.LOT_ADV_ALL);
        sleep(1000);

        //LPS ADVANCE SALES REPORT ALL

        Singleton.changeSubGame(Constants.LPS_ADV_SUB_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.LPS_ADV_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.LPS_ADV_ALL);
        sleep(1000);

        //EUM ADVANCE SALES REPORT ALL

        Singleton.changeGame(Constants.EUM_ADV_SUB_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.EUM_ADV_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.EUM_ADV_ALL);
        sleep(1000);

        //EPS ADVANCE SALES REPORT ALL

        Singleton.changeSubGame(Constants.EPS_ADV_SUB_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.EPS_ADV_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.EPS_ADV_ALL);
        sleep(1000);

        //IOR ADVANCE SALES REPORT ALL

        Singleton.changeSubGame(Constants.IOR_ADV_SUB_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.IOR_ADV_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.IOR_ADV_ALL);
        sleep(1000);

        //DMN ADVANCE SALES REPORT ALL

        Singleton.changeGame(Constants.DMN_ADV_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.DMN_ADV_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.DMN_ADV_ALL);
        sleep(1000);


        // DMP ADVANCE SALES REPORT ALL
        Singleton.changeSubGame(Constants.DMP_ADV_SUB_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.DMP_ADV_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.DMP_ADV_ALL);
        sleep(1000);

        //RAF ADVANCE SALES TERMINAL REPORT
        Singleton.changeChannel(Constants.ADV_TERMINAL);
        Singleton.changeGame(Constants.RAF_ADV_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.RAF_ADV_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.RAF_ADV_TERMINAL);
        sleep(1000);

        //LOT ADVANCE SALES TERMINAL REPORT

        Singleton.changeGame(Constants.LOT_ADV_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.LOT_ADV_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.LOT_ADV_TERMINAL);
        sleep(1000);

        //LPS ADVANCE SALES TERMINAL REPORT

        Singleton.changeSubGame(Constants.LPS_ADV_SUB_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.LPS_ADV_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.LPS_ADV_TERMINAL);
        sleep(1000);

        //EUM  ADVANCE SALES TERMINAL REPORT

        Singleton.changeGame(Constants.EUM_ADV_SUB_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.EUM_ADV_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.EUM_ADV_TERMINAL);
        sleep(1000);

        //EPS ADVANCE SALES TERMINAL REPORT

        Singleton.changeSubGame(Constants.EPS_ADV_SUB_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.EPS_ADV_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.EPS_ADV_TERMINAL);
        sleep(1000);


        //IOR ADVANCE SALES TERMINAL REPORT

        Singleton.changeSubGame(Constants.IOR_ADV_SUB_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.IOR_ADV_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.IOR_ADV_TERMINAL);
        sleep(1000);

        //DMN ADVANCE SALES TERMINAL REPORT

        Singleton.changeGame(Constants.DMN_ADV_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.DMN_ADV_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.DMN_ADV_TERMINAL);
        sleep(1000);

        //DMP ADVANCE SALES TERMINAL REPORT

        Singleton.changeSubGame(Constants.DMP_ADV_SUB_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.DMP_ADV_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.DMP_ADV_TERMINAL);
        sleep(1000);

        // L54321  ADVANCE SALES TERMINAL REPORT

        Singleton.changeGame(Constants.L54321_ADV_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.L5_ADV_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.L5_ADV_TERMINAL);
        sleep(1000);

        // L54321 + 1  ADVANCE SALES TERMINAL REPORT

        Singleton.changeSubGame(Constants.L51_ADV_SUB_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.L51_ADV_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.L51_ADV_TERMINAL);
        sleep(1000);

        // L54321 + 2  ADVANCE SALES TERMINAL REPORT

        Singleton.changeSubGame(Constants.L52_ADV_SUB_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.L52_ADV_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.L52_ADV_TERMINAL);
        sleep(1000);

        //TVB  ADVANCE SALES TERMINAL REPORT

        Singleton.changeGame(Constants.TVB_ADV_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.TVB_ADV_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.TVB_ADV_TERMINAL);
        sleep(1000);


        //RAF ADVANCE SALES REPORT INTERNET

        Singleton.changeChannel(Constants.ADV_INTERNET);
        Singleton.changeGame(Constants.RAF_ADV_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.RAF_ADV_INTERNET);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.RAF_ADV_INTERNET);
        sleep(1000);

        //LOT ADVANCE SALES REPORT INTERNET

        Singleton.changeGame(Constants.LOT_ADV_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.LOT_ADV_INTERNET);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.LOT_ADV_INTERNET);
        sleep(1000);

        //LPS ADVANCE SALES REPORT INTERNET

        Singleton.changeSubGame(Constants.LPS_ADV_SUB_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.LPS_ADV_INTERNET);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.LPS_ADV_INTERNET);
        sleep(1000);


        //EUM ADVANCE SALES REPORT INTERNET

        Singleton.changeGame(Constants.EUM_ADV_SUB_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.EUM_ADV_INTERNET);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.EUM_ADV_INTERNET);
        sleep(1000);

        //EPS ADVANCE SALES REPORT INTERNET

        Singleton.changeSubGame(Constants.EPS_ADV_SUB_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.EPS_ADV_INTERNET);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.EPS_ADV_INTERNET);
        sleep(1000);

        //IOR ADVANCE SALES REPORT INTERNET

        Singleton.changeSubGame(Constants.IOR_ADV_SUB_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.IOR_ADV_INTERNET);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.IOR_ADV_INTERNET);
        sleep(1000);

        //DMN ADVANCE SALES REPORT INTERNET

        Singleton.changeGame(Constants.DMN_ADV_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.DMN_ADV_INTERNET);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.DMN_ADV_INTERNET);
        sleep(1000);

        //DMP ADVANCE SALES REPORT INTERNET

        Singleton.changeSubGame(Constants.DMP_ADV_SUB_GAME_FIELD, Constants.PDF_ADV_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.DMP_ADV_INTERNET);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.DMP_ADV_INTERNET);
        sleep(1000);




        Singleton.close();
        Singleton.quit();
    }
}
