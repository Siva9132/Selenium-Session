package junit.test;

import Utils.test.Constants;
import Utils.test.Singleton;
import com.sun.tools.javac.Main;
import org.junit.platform.commons.logging.LoggerFactory;

import java.awt.*;

import static Utils.test.Util.sleep;


public class Boipa {



    @org.junit.jupiter.api.Test
    public void boipa() throws InterruptedException, AWTException {

        //BIOPA CASHIN TRANSACTIONS


        Singleton.initialize();

        Singleton.logOn();
        Singleton.navigationBoipa(Constants.REPORTS,Constants.REPORTS_PCLUB, Constants.BOIPA_WEB_CASHIN,
                Constants.BOIPA_DATEPICKER1, Constants.BOIPA_DATEPICKER2, Constants.BOIPA_PDF_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.WEB_CASHIN_TRANSACTIONS);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.WEB_CASHIN_TRANSACTIONS);
        sleep(1000);
        Singleton.mouseClosePdfWallet(Constants.WALLET_CLOSING_XX, Constants.WALLET_CLOSING_YY);


        //BOIPA TRANSACIONS REPORT

        Singleton.navigationBoipaNext(Constants.REPORTS_PCLUB, Constants.BOIPA_TRANSACTIONS,
                Constants.BOIPA_TRAN_DATEPICKER1, Constants.BOIPA_TRAN_DATEPICKER2, Constants.BOIPA_TRAN_PDF_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.BOIPA_TRANSACTIONS_REPORT);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.BOIPA_TRANSACTIONS_REPORT);
        sleep(1000);
        Singleton.mouseClosePdfWallet(Constants.WALLET_CLOSING_XX, Constants.WALLET_CLOSING_YY);

        //BOIPA ADD FUNDS REPORT ALL

        Singleton.navigationBoipaNext(Constants.REPORTS_PCLUB, Constants.BOIPA_ADD_FUNDS_REPORT,
                Constants.BOIPA_FUNDS_DATEPICKER1, Constants.BOIPA_FUNDS_DATEPICKER2, Constants.BOIPA_FUNDS_PDF_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.BOIPA_ADD_FUNDS_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.BOIPA_ADD_FUNDS_ALL);
        sleep(1000);


        //BOIPA ADD FUNDS REPORT PENDING RESPONSE

        Singleton.changeSubGame(Constants.PENDING_RESPONSE,Constants.BOIPA_FUNDS_PDF_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.BOIPA_ADD_FUNDS_PENDING_RES);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.BOIPA_ADD_FUNDS_PENDING_RES);
        sleep(1000);

        //BOIPA ADD FUNDS REPORT PENDING

        Singleton.changeSubGame(Constants.PENDING,Constants.BOIPA_FUNDS_PDF_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.BOIPA_ADD_FUNDS_PENDING);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.BOIPA_ADD_FUNDS_PENDING);
        sleep(1000);

        // //BOIPA ADD FUNDS REPORT SUCCESS

        Singleton.changeSubGame(Constants.SUCCESS,Constants.BOIPA_FUNDS_PDF_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.BOIPA_ADD_FUNDS_SUCCESS);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.BOIPA_ADD_FUNDS_SUCCESS);
        sleep(1000);


        //BOIPA ADD FUNDS REPORT REJECTED BY PP

        Singleton.changeSubGame(Constants.REJECTED_BY_PP,Constants.BOIPA_FUNDS_PDF_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.BOIPA_ADD_FUNDS_REJECTED_PP);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.BOIPA_ADD_FUNDS_REJECTED_PP);
        sleep(1000);

        Singleton.quit();

    }


}
