package junit.test;

import Utils.test.Constants;
import Utils.test.Singleton;

import java.awt.*;

import static Utils.test.Util.sleep;

public class ProductDrawSales {


    @org.junit.jupiter.api.Test
    public void bosProductDrawSales() throws InterruptedException, AWTException {


        //RAF SALES_PER_PRODUCT_TYPE_ALL
        Singleton.initialize();
        Singleton.logOn();
        Singleton.navigationTransactions(Constants.BOS_LINK_DAILY,Constants.SUBMENU_ADV_REPORT, Constants.LINK_TO_SALES_PER_PRODUCT_TYPE, Constants.DATE_TRANS_PICKER1_SPPT
                ,Constants.DATE_TRANS_PICKER2_SPPT , Constants.TANS_BUTTON_SPPT);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.RAF_SALES_PER_PRODUCT_TYPE_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);

        System.out.println("Download Completed :" + Constants.RAF_SALES_PER_PRODUCT_TYPE_ALL);
        sleep(1000);

        //LOT SALES_PER_PRODUCT_TYPE_ALL

        Singleton.changeGame(Constants.LOT_TRANS_PER_PRODUCT_TYPE_ADDRESS,Constants.TANS_BUTTON_SPPT);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.LOT_SALES_PER_PRODUCT_TYPE_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.LOT_SALES_PER_PRODUCT_TYPE_ALL);
        sleep(1000);

        //LPS SALES_PER_PRODUCT_TYPE_ALL

        Singleton.changeSubGame(Constants.LPS_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.LPS_SALES_PER_PRODUCT_TYPE_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.LPS_SALES_PER_PRODUCT_TYPE_ALL);
        sleep(1000);

        //EUM SALES_PER_PRODUCT_TYPE_ALL

        Singleton.changeGame(Constants.EUM_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.EUM_SALES_PER_PRODUCT_TYPE_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.EUM_SALES_PER_PRODUCT_TYPE_ALL);
        sleep(1000);

        //EPS SALES_PER_PRODUCT_TYPE_ALLLOT Sales Per Product Type - All

        Singleton.changeSubGame(Constants.EPS_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.EPS_SALES_PER_PRODUCT_TYPE_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.EPS_SALES_PER_PRODUCT_TYPE_ALL);
        sleep(1000);

        //IOR SALES_PER_PRODUCT_TYPE_ALL

        Singleton.changeSubGame(Constants.IOR_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.IOR_SALES_PER_PRODUCT_TYPE_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.IOR_SALES_PER_PRODUCT_TYPE_ALL);
        sleep(1000);

        //DMN SALES_PER_PRODUCT_TYPE_ALL

        Singleton.changeGame(Constants.DMN_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.DMN_SALES_PER_PRODUCT_TYPE_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.DMN_SALES_PER_PRODUCT_TYPE_ALL);
        sleep(1000);


        // DMP SALES_PER_PRODUCT_TYPE_ALL
        Singleton.changeSubGame(Constants.DMP_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.DMP_SALES_PER_PRODUCT_TYPE_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.DMP_SALES_PER_PRODUCT_TYPE_ALL);
        sleep(1000);

        // L54321 SALES_PER_PRODUCT_TYPE_ALL
        Singleton.changeSubGame(Constants.L54321_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.L54321_SALES_PER_PRODUCT_TYPE_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.L54321_SALES_PER_PRODUCT_TYPE_ALL);
        sleep(1000);

        // L54321+1 SALES_PER_PRODUCT_TYPE_ALL
        Singleton.changeSubGame(Constants.L54321_1_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.L54321_1_SALES_PER_PRODUCT_TYPE_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.L54321_1_SALES_PER_PRODUCT_TYPE_ALL);
        sleep(1000);

        // L54321+2 SALES_PER_PRODUCT_TYPE_ALL
        Singleton.changeSubGame(Constants.L54321_2_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.L54321_2_SALES_PER_PRODUCT_TYPE_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.L54321_2_SALES_PER_PRODUCT_TYPE_ALL);
        sleep(1000);


        // TVB SALES_PER_PRODUCT_TYPE_ALL




        Singleton.changeSubGame(Constants.TVB_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.TVB_SALES_PER_PRODUCT_TYPE_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.TVB_SALES_PER_PRODUCT_TYPE_ALL);
        sleep(1000);







        //TERMINAL

        //RAF SALES_PER_PRODUCT_TYPE_TERMINAL



        Singleton.changeChannel(Constants.SPPT_TERMINAL);
        Singleton.changeGame(Constants.RAF_TRANS_PER_PRODUCT_TYPE_ADDRESS,Constants.TANS_BUTTON_SPPT);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.RAF_SALES_PER_PRODUCT_TYPE_Terminal);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.RAF_SALES_PER_PRODUCT_TYPE_Terminal);
        sleep(1000);

        //LOT SALES_PER_PRODUCT_TYPE_TERMINAL

        Singleton.changeGame(Constants.LOT_TRANS_PER_PRODUCT_TYPE_ADDRESS,Constants.TANS_BUTTON_SPPT);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.LOT_SALES_PER_PRODUCT_TYPE_Terminal);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.LOT_SALES_PER_PRODUCT_TYPE_Terminal);
        sleep(1000);

        //LPS SALES_PER_PRODUCT_TYPE_TERMINAL

        Singleton.changeSubGame(Constants.LPS_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.LPS_SALES_PER_PRODUCT_TYPE_Terminal);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.LPS_SALES_PER_PRODUCT_TYPE_Terminal);
        sleep(1000);

        //EUM SALES_PER_PRODUCT_TYPE_TERMINAL

        Singleton.changeGame(Constants.EUM_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.EUM_SALES_PER_PRODUCT_TYPE_Terminal);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.EUM_SALES_PER_PRODUCT_TYPE_Terminal);
        sleep(1000);

        //EPS SALES_PER_PRODUCT_TYPE_TERMINAL

        Singleton.changeSubGame(Constants.EPS_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.EPS_SALES_PER_PRODUCT_TYPE_Terminal);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.EPS_SALES_PER_PRODUCT_TYPE_Terminal);
        sleep(1000);

        //IOR SALES_PER_PRODUCT_TYPE_TERMINAL

        Singleton.changeSubGame(Constants.IOR_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.IOR_SALES_PER_PRODUCT_TYPE_Terminal);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.IOR_SALES_PER_PRODUCT_TYPE_Terminal);
        sleep(1000);

        //DMN SALES_PER_PRODUCT_TYPE_TERMINAL

        Singleton.changeGame(Constants.DMN_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.DMN_SALES_PER_PRODUCT_TYPE_Terminal);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.DMN_SALES_PER_PRODUCT_TYPE_Terminal);
        sleep(1000);


        // DMP SALES_PER_PRODUCT_TYPE_TERMINAL
        Singleton.changeSubGame(Constants.DMP_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.DMP_SALES_PER_PRODUCT_TYPE_Terminal);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.DMP_SALES_PER_PRODUCT_TYPE_Terminal);
        sleep(1000);

        // L54321 SALES_PER_PRODUCT_TYPE_TERMINAL
        Singleton.changeSubGame(Constants.L54321_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.L54321_SALES_PER_PRODUCT_TYPE_Terminal);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.L54321_SALES_PER_PRODUCT_TYPE_Terminal);
        sleep(1000);

        // L54321+1 SALES_PER_PRODUCT_TYPE_TERMINAL
        Singleton.changeSubGame(Constants.L54321_1_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.L54321_1_SALES_PER_PRODUCT_TYPE_Terminal);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.L54321_1_SALES_PER_PRODUCT_TYPE_Terminal);
        sleep(1000);

        // L54321+2 SALES_PER_PRODUCT_TYPE_TERMINAL
        Singleton.changeSubGame(Constants.L54321_2_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.L54321_2_SALES_PER_PRODUCT_TYPE_Terminal);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.L54321_2_SALES_PER_PRODUCT_TYPE_Terminal);
        sleep(1000);


        // TVB SALES_PER_PRODUCT_TYPE_TERMINAL


        Singleton.changeSubGame(Constants.TVB_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.TVB_SALES_PER_PRODUCT_TYPE_Terminal);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.TVB_SALES_PER_PRODUCT_TYPE_Terminal);
        sleep(1000);



        //INTERNET

        //RAF SALES_PER_PRODUCT_TYPE_INTERNET



        Singleton.changeChannel(Constants.SPPT_INTERNET);
        Singleton.changeGame(Constants.RAF_TRANS_PER_PRODUCT_TYPE_ADDRESS,Constants.TANS_BUTTON_SPPT);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.RAF_SALES_PER_PRODUCT_TYPE_Internet);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.RAF_SALES_PER_PRODUCT_TYPE_Internet);
        sleep(1000);

        //LOT SALES_PER_PRODUCT_TYPE_INTERNET

        Singleton.changeGame(Constants.LOT_TRANS_PER_PRODUCT_TYPE_ADDRESS,Constants.TANS_BUTTON_SPPT);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.LOT_SALES_PER_PRODUCT_TYPE_Internet);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.LOT_SALES_PER_PRODUCT_TYPE_Internet);
        sleep(1000);

        //LPS SALES_PER_PRODUCT_TYPE_INTERNET

        Singleton.changeSubGame(Constants.LPS_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.LPS_SALES_PER_PRODUCT_TYPE_Internet);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.LPS_SALES_PER_PRODUCT_TYPE_Internet);
        sleep(1000);

        //EUM SALES_PER_PRODUCT_TYPE_INTERNET

        Singleton.changeGame(Constants.EUM_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.EUM_SALES_PER_PRODUCT_TYPE_Internet);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.EUM_SALES_PER_PRODUCT_TYPE_Internet);
        sleep(1000);

        //EPS SALES_PER_PRODUCT_TYPE_INTERNET

        Singleton.changeSubGame(Constants.EPS_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.EPS_SALES_PER_PRODUCT_TYPE_Internet);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.EPS_SALES_PER_PRODUCT_TYPE_Internet);
        sleep(1000);

        //IOR SALES_PER_PRODUCT_TYPE_INTERNET

        Singleton.changeSubGame(Constants.IOR_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.IOR_SALES_PER_PRODUCT_TYPE_Internet);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.IOR_SALES_PER_PRODUCT_TYPE_Internet);
        sleep(1000);

        //DMN SALES_PER_PRODUCT_TYPE_INTERNET

        Singleton.changeGame(Constants.DMN_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.DMN_SALES_PER_PRODUCT_TYPE_Internet);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.DMN_SALES_PER_PRODUCT_TYPE_Internet);
        sleep(1000);


        // DMP SALES_PER_PRODUCT_TYPE_INTERNET
        Singleton.changeSubGame(Constants.DMP_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.DMP_SALES_PER_PRODUCT_TYPE_Internet);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.DMP_SALES_PER_PRODUCT_TYPE_Internet);
        sleep(1000);

        // L54321 SALES_PER_PRODUCT_TYPE_INTERNET
        Singleton.changeSubGame(Constants.L54321_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.L54321_SALES_PER_PRODUCT_TYPE_Internet);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.L54321_SALES_PER_PRODUCT_TYPE_Internet);
        sleep(1000);

        // L54321+1 SALES_PER_PRODUCT_TYPE_INTERNET
        Singleton.changeSubGame(Constants.L54321_1_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.L54321_1_SALES_PER_PRODUCT_TYPE_Internet);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.L54321_1_SALES_PER_PRODUCT_TYPE_Internet);
        sleep(1000);

        // L54321+2 SALES_PER_PRODUCT_TYPE_INTERNET
        Singleton.changeSubGame(Constants.L54321_2_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.L54321_2_SALES_PER_PRODUCT_TYPE_Internet);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.L54321_2_SALES_PER_PRODUCT_TYPE_Internet);
        sleep(1000);


        // TVB SALES_PER_PRODUCT_TYPE_INTERNET


        Singleton.changeSubGame(Constants.TVB_TRANS_PER_PRODUCT_TYPE_NAME_ADDRESS,Constants.TANS_BUTTON_SPPT );
        Singleton.mouseSave();
        Singleton.getReportName(Constants.TVB_SALES_PER_PRODUCT_TYPE_Internet);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.TVB_SALES_PER_PRODUCT_TYPE_Internet);
        sleep(1000);


        Singleton.close();
        Singleton.quit();

    }
}
