package junit.test;

import Utils.test.Constants;
import Utils.test.Singleton;
import java.awt.*;
import static Utils.test.Singleton.navigationGame;
import static Utils.test.Util.*;

public class DailyGameWalletReport {


    @org.junit.jupiter.api.Test
    public void dailyGameWalletReport() throws InterruptedException, AWTException {

        //BOS DAILY REPORT ALL


        Singleton.initialize();
        Singleton.logOn();
        Singleton.navigationDaily(Constants.REPORTS, Constants.DAILY_REPORT, Constants.LINK_TO_DAILY_REPORT, Constants.DATE_PICKER, Constants.RANGE_ALL_START, Constants.RANGE_ALL_END, Constants.PDF_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.ACC_DAILY_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.ACC_DAILY_ALL);
        sleepShort();

        //BOS DAILY REPORT TERMINAL
        Singleton.navigationDailyNext(Constants.RANGE_ALL_START, Constants.RANGE_TERMINAL_END, Constants.PDF_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.ACC_DAILY_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.ACC_DAILY_TERMINAL);
        sleepShort();


        //BOS DAILY REPORT INTERNET
        Singleton.navigationDailyNext(Constants.RANGE_INTERNET_START, Constants.RANGE_INTERNET_END, Constants.PDF_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.ACC_DAILY_INTERNET);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.ACC_DAILY_INTERNET);
        sleepShort();


        //BOS GAME REPORT ALL


        navigationGame(Constants.SUBMENU_ACC_REPORT, Constants.LINK_TO_GAME_REPORT, Constants.GAME_DATE_PICKER, Constants.PDF_GAME_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.ACC_GAME_ALL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.ACC_GAME_ALL);
        sleepShort();


        //BOS GAME REPORT TERMINAL

        Singleton.changeSubGame(Constants.GAME_SELECTOR_TERMINAL, Constants.PDF_GAME_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.ACC_GAME_TERMINAL);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.ACC_GAME_TERMINAL);
        sleepShort();


        //BOS GAME REPORT INTERNET


        Singleton.navigationGameNext(Constants.GAME_SELECTOR_INTERNET, Constants.PDF_GAME_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.ACC_GAME_INTERNET);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.ACC_GAME_INTERNET);
        sleepShort();


        //BOS OVERALL WALLET TRANSACTIONS
        Singleton.mouseClosePdfWallet(Constants.WALLET_CLOSING_XX, Constants.WALLET_CLOSING_YY);
        Singleton.navigationWallet(Constants.SUBMENU_WALLET_REPORT, Constants.LINK_WALLET_REPORT, Constants.WALL_DATE_PICKER_1, Constants.WALL_DATE_PICKER_2
                , Constants.WALL_PDF_BUTTON);
        Singleton.mouseSave();
        getReportName(Constants.OVERALL_WALLET);
        Singleton.mouseConfirm();
        System.out.println("Download Completed :" + Constants.OVERALL_WALLET);
        sleep(2000);
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        sleep(2000);
        Singleton.mouseClosePdfWallet(Constants.WALLET_CLOSING_XX, Constants.WALLET_CLOSING_YY);

        //WALLET TRANSACTIONS PER REGISTERED PLAYERS

        Singleton.navigationWalletNext(Constants.SUBMENU_WALLET_REPORT, Constants.LINK_WALL_REG_REPORT, Constants.WALL_REG_DATE_PICKER,
                Constants.RANGE_FIELD_1, Constants.RANGE_FIELD_2, Constants.RANGE_NUM_START, Constants.RANGE_NUM_END, Constants.WALL_REG_PDF_BUTTON);

        Singleton.mouseSave();
        getReportName(Constants.WALLET_TRANSACTIONS_PER_PLAYERS);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        sleep(2000);
        Singleton.mouseClosePdf(Constants.WALLET_CLOSING_XX, Constants.WALLET_CLOSING_YY);
        sleep(2000);
        System.out.println("Download Completed :" + Constants.WALLET_TRANSACTIONS_PER_PLAYERS);
        sleepShort();

        Singleton.close();
        Singleton.quit();


    }
}
