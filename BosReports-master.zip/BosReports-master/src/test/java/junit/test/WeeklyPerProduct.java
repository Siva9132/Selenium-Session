package junit.test;
import Utils.test.Constants;
import Utils.test.Singleton;
import java.awt.*;
import static Utils.test.Util.sleep;

public class WeeklyPerProduct {

    @org.junit.jupiter.api.Test
    public void dailyGameWalletReport() throws InterruptedException, AWTException {

        //BOS DAILY REPORT ALL


        Singleton.initialize();
        Singleton.logOn();
        Singleton.navigationWeekly(Constants.BOS_LINK_DAILY, Constants.SUBMENU_ACC_REPORT,Constants.LINK_WEEKLY_PER_PRODUCT,
                Constants.FROM_YEAR,Constants.TO_YEAR,Constants.RANGE_NUM_START,Constants.RANGE_TERMINAL_END,
                Constants.WEEKLY_PER_PRODUCT_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.INSTANT_WEEKLY);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.INSTANT_WEEKLY);
        sleep(1000);

        Singleton.changeGame(Constants.RAF_WEEKLY_PER_PRODUCT,Constants.WEEKLY_PER_PRODUCT_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.RAF_WEEKLY);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.RAF_WEEKLY);
        sleep(1000);

        Singleton.changeGame(Constants.LOT_WEEKLY_PER_PRODUCT,Constants.WEEKLY_PER_PRODUCT_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.LOT_WEEKLY);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.LOT_WEEKLY);
        sleep(1000);


        Singleton.changeSubGame(Constants.LPS_WEEKLY_PER_PRODUCT,Constants.WEEKLY_PER_PRODUCT_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.LPS_WEEKLY);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.LPS_WEEKLY);
        sleep(1000);

        Singleton.changeGame(Constants.EUM_WEEKLY_PER_PRODUCT,Constants.WEEKLY_PER_PRODUCT_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.EUM_WEEKLY);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.EUM_WEEKLY);
        sleep(1000);

        Singleton.changeSubGame(Constants.EPS_WEEKLY_PER_PRODUCT,Constants.WEEKLY_PER_PRODUCT_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.EPS_WEEKLY);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.EPS_WEEKLY);
        sleep(1000);


        Singleton.changeSubGame(Constants.IOR_WEEKLY_PER_PRODUCT,Constants.WEEKLY_PER_PRODUCT_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.IOR_WEEKLY);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.IOR_WEEKLY);
        sleep(1000);

        Singleton.changeGame(Constants.DMN_WEEKLY_PER_PRODUCT,Constants.WEEKLY_PER_PRODUCT_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.DMN_WEEKLY);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.DMN_WEEKLY);
        sleep(1000);

        Singleton.changeSubGame(Constants.DMP_WEEKLY_PER_PRODUCT,Constants.WEEKLY_PER_PRODUCT_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.DMP_WEEKLY);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.DMP_WEEKLY);
        sleep(1000);

        Singleton.changeGame(Constants.L5_WEEKLY_PER_PRODUCT,Constants.WEEKLY_PER_PRODUCT_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.L5_WEEKLY);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.L5_WEEKLY);
        sleep(1000);

        Singleton.changeSubGame(Constants.L51_WEEKLY_PER_PRODUCT,Constants.WEEKLY_PER_PRODUCT_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.L51_WEEKLY);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.L51_WEEKLY);
        sleep(1000);

        Singleton.changeSubGame(Constants.L52_WEEKLY_PER_PRODUCT,Constants.WEEKLY_PER_PRODUCT_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.L52_WEEKLY);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.L52_WEEKLY);
        sleep(1000);


        Singleton.changeGame(Constants.TVB_WEEKLY_PER_PRODUCT,Constants.WEEKLY_PER_PRODUCT_BUTTON);
        Singleton.mouseSave();
        Singleton.getReportName(Constants.TVB_WEEKLY);
        Singleton.mouseConfirm();
        Singleton.mouseClosePdf(Constants.X, Constants.Y);
        System.out.println("Download Completed :" + Constants.TVB_WEEKLY);
        sleep(1000);

        Singleton.close();
        Singleton.quit();






    }

}
